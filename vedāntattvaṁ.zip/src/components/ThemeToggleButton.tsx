import React from "react";

export default function ThemeToggleButton() {
  // Theme option removed per requirement; app is permanently in Golden Ivory theme.
  return null;
}

