import { GranthaChapter } from "./types";

// =========================================================================================
// CHAPTER 3: SṚṢṬI-KRAMA, ŚARĪRA-TRAYA & PAÑCĪKARAṆA (Sections 12 - 18)
// =========================================================================================
export const VEDANTASARA_CHAPTER_3: GranthaChapter = {
  id: "vs-adhyaya-3",
  chapterTitle: "Chapter 3: Sṛṣṭi-Krama, Śarīra-Traya & Pañcīkaraṇa",
  chapterTitleSanskrit: "तृतीयोऽध्यायः — सृष्टिक्रमः शरीरत्रयं पञ्चीकरणञ्च",
  summary:
    "The evolution of subtle elements (Tanmātrāṇi); the seventeenfold subtle body (Liṅga-Śarīra) and the three inner sheaths; Hiraṇyagarbha and Taijasa in the dream state; the process of grossification (Pañcīkaraṇa); creation of the fourteen cosmic worlds; the four classes of gross bodies; Virāṭ and Viśva in the waking state; and cosmic integration under 'Sarvaṁ Khalvidaṁ Brahma'.",
  verses: [
    {
      id: "vs-12",
      number: "Section 12",
      title: "Evolution of the Five Subtle Elements (Tanmātrāṇi)",
      mulaSanskrit: `तमःप्रधानविक्षेपशक्तिमदज्ञानोपहितचैतन्यादाकाश आकाशाद्वायुर्वायोरग्निरग्नेरापोऽद्भ्यः पृथिवी चोत्पद्यते 'एतस्मादात्मन आकाशः सम्भूतः' (तै. उ. २ । १ । १) इत्यादिश्रुतेः । तेषु जाड्याधिक्यदर्शनात्तमःप्राधान्यं तत्कारणस्य । तदानीं सत्त्वरजस्तमांसि कारणगुणप्रक्रमेण तेष्वाकाशादिषूत्पद्यन्ते । एतान्येव सूक्ष्मभूतानि तन्मात्राण्यपञ्चीकृतानि चोच्यन्ते । एतेभ्यः सूक्ष्मशरीराणि स्थूलभूतानि चोत्पद्यन्ते ॥ १२ ॥`,
      mulaIast: "tamaḥpradhānavikṣepaśaktimad-ajñānopahitacaitanyād ākāśa ākāśād vāyur vāyor agnir agner āpo'dbhyaḥ pṛthivī cotpadyate... eteṣu jāḍyādhikyadarśanāt tamaḥprādhānyaṁ tatkāraṇasya... etāny eva sūkṣmabhūtāni tanmātrāṇy apañcīkṛtāni cocyante... || 12 ||",
      padaccheda: "तमः-प्रधान-विक्षेप-शक्तिमत्-अज्ञान-उपहित-चैतन्यात्, आकाशः, आकाशात्, वायुः, वायोः, अग्निः, अग्नेः, आपः, अद्भ्यः, पृथिवी, च, उत्पद्यते ...",
      anvaya: "तमःप्रधानविक्षेपशक्तिमदज्ञानोपहितचैतन्यादाकाशादीनि पञ्च सूक्ष्मभूतानि जायन्ते । एतान्येव तन्मात्राण्यपञ्चीकृतानि चोच्यन्ते ।",
      bhashyaExtract: "जगतो जडत्वदर्शनात् तमोगुणस्य प्राधान्यम् । आकाशादिक्रमेण सूक्ष्मभूतोत्पत्तिः श्रुतिसिद्धा ।",
      englishTranslation: "From Consciousness conditioned by Ignorance predominated by Tamas and endowed with the projecting power (Vikṣepa-śakti), space (Ākāśa) is born; from space, air (Vāyu); from air, fire (Agni); from fire, water (Āpas); and from water, earth (Pṛthivī), as stated in the Śruti: 'From this Self, space was born' (Taittirīya 2.1.1). Because inertia (Jāḍya) is observed in excess in these elements, the Tamas quality is predominant in their cause. These very subtle elements are termed Tanmātras and uncompounded (Apañcīkṛta) elements. From these are produced the subtle bodies and the gross elements.",
      commentaryNotes: "Systematizes the sequential cosmetic projection of the subtle elements from the unmanifest ground."
    },
    {
      id: "vs-13",
      number: "Section 13",
      title: "The Seventeenfold Subtle Body (Liṅga-Śarīra) and the Three Sheaths",
      mulaSanskrit: `सूक्ष्मशरीराणि सप्तदशावयवानि लिङ्गशरीराणि । अवयवास्तु ज्ञानेन्द्रियपञ्चकं बुद्धिमनसी कर्मेन्द्रियपञ्चकं वायुपञ्चकं चेति ।

ज्ञानेन्द्रियाणि श्रोत्रत्वक्चक्षुर्जिह्वाघ्राणाख्यानि । एतान्याकाशादीनां सात्त्विकांशेभ्यो व्यस्तेभ्यः पृथक् पृथक् क्रमेणोत्पद्यन्ते । बुद्धिर्नाम निश्चयात्मिकाऽन्तःकरणवृत्तिः । मनो नाम सङ्कल्पविकल्पात्मिकान्तःकरणवृत्तिः । अनयोरेव चित्ताहङ्कारयोरन्तर्भावः । अनुसन्धानात्मिकान्तःकरणवृत्तिः चित्तम् । अभिमानात्मिकान्तःकरणवृत्तिः अहङ्कारः । एते पुनराकाशादिगतसात्त्विकांशेभ्यो मिलितेभ्य उत्पद्यन्ते । एतेषां प्रकाशात्मकत्वात्सात्त्विकांशकार्यत्वम् ।

इयं बुद्धिर्ज्ञानेन्द्रियैः सहिता विज्ञानमयकोशो भवति । अयं कर्तृत्वभोक्तृत्वसुखित्वदुःखित्वाद्यभिमानत्वेनेहलोकपरलोकगामी व्यवहारिको जीव इत्युच्यते । मनस्तु ज्ञानेन्द्रियैः सहितं सन्मनोमयकोशो भवति ।

कर्मेन्द्रियाणि वाक्पाणिपादपायूपस्थाख्यानि । एतानि पुनराकाशादीनां रजोंशेभ्यो व्यस्तेभ्यः पृथक् पृथक् क्रमेणोत्पद्यन्ते ।

वायवः प्राणापानव्यानोदानसमानाः । प्राणो नाम प्राग्गमनवान्नासाग्रस्थानवर्ती । अपानो नामावाग्गमनवान्पाय्वादिस्थानवर्ती । व्यानो नाम विष्वग्गमनवानखिलशरीरवर्ती । उदानो नाम कण्ठस्थानीय ऊर्ध्वगमनवानुत्क्रमणवायुः । समानो नाम शरीरमध्यगताशितपीतान्नादिसमीकरणकरः । समीकरणन्तु परिपाककरणं रसरुधिरशुक्रपुरीषादिकरणमिति यावत् । केचित्तु नागकूर्मकृकलदेवदत्तधनञ्जयाख्याः पञ्चान्ये वायवः सन्तीति वदन्ति... एतत्प्राणादिपञ्चकमाकाशादिगतरजोंशेभ्योमिलितेभ्य उत्पद्यते । इदं प्राणादिपञ्चकं कर्मेन्द्रियैः सहितं सत्प्राणमयकोशो भवति । अस्य क्रियात्मकत्वेन रजोंशकार्यत्वम् ।

एतेषु कोशेषु मध्ये विज्ञानमयो ज्ञानशक्तिमान् कर्तृरूपः । मनोमय इच्छाशक्तिमान् करणरूपः । प्राणमयः क्रियाशक्तिमान् कार्यरूपः । योग्यत्वादेवमेतेषां विभाग इति वर्णयन्ति । एतत्कोशत्रयं मिलितं सत्सूक्ष्मशरीरमित्युच्यते ॥ १३ ॥`,
      mulaIast: `sūkṣmaśarīrāṇi saptadaśāvayavāni liṅgaśarīrāṇi | avayavās tu jñānendriyapañcakaṁ buddhimanasī karmendriyapañcakaṁ vāyupañcakaṁ ceti... iyaṁ buddhir jñānendriyaiḥ sahitā vijñānamayakośo bhavati... manas tu jñānendriyaiḥ sahitaṁ san manomayakośo bhavati... idaṁ prāṇādipañcakaṁ karmendriyaiḥ sahitaṁ sat prāṇamayakośo bhavati... etat kośatrayaṁ militaṁ sat sūkṣmaśarīram ity ucyate || 13 ||`,
      padaccheda: "सूक्ष्म-शरीराणि, सप्तदश-अवयवानि, लिङ्ग-शरीराणि । अवयवाः, तु, ज्ञानेन्द्रिय-पञ्चकम्, बुद्धि-मनसी, कर्मेन्द्रिय-पञ्चकम्, वायु-पञ्चकम्, च, इति ...",
      anvaya: "सूक्ष्मशरीराणि सप्तदशावयवानि । ज्ञानेन्द्रियपञ्चकं बुद्धिमनसी कर्मेन्द्रियपञ्चकं वायुपञ्चकं चेति । बुद्धिर्ज्ञानेन्द्रियैर्विज्ञानमयः, मनो ज्ञानेन्द्रियैर्मनोमयः, प्राणाः कर्मेन्द्रियैः प्राणमयः । एतत्कोशत्रयं सूक्ष्मशरीरम् ।",
      bhashyaExtract: "सप्तदशावयवात्मकं लिङ्गशरीरम् आत्मनो भोगायतनं परलोकगामि च यावन्मोक्षं तिष्ठति ।",
      englishTranslation: "The subtle bodies (Sūkṣma-Śarīra or Liṅga-Śarīra) consist of seventeen constituent limbs: the five organs of knowledge (hearing, touch, sight, taste, smell), the intellect (Buddhi) and the mind (Manas), the five organs of action (speech, hands, feet, evacuation, generation), and the five vital airs (Prāṇa, Apāna, Vyāna, Udāna, Samāna). The intellect combined with the organs of knowledge constitutes the Intellectual Sheath (Vijñānamayakośa)—which, identifying with agency, enjoyership, pleasure, and pain, transmigrates between this world and the next as the empirical soul (Vyāvahārika Jīva). The mind combined with the organs of knowledge forms the Mental Sheath (Manomayakośa). The five vital airs combined with the organs of action form the Vital Sheath (Prāṇamayakośa). Among these sheaths, Vijñānamaya is endowed with the power of knowledge and is the agent (Kartṛ); Manomaya is endowed with the power of will and is the instrument (Karaṇa); Prāṇamaya is endowed with the power of action and is the effect (Kārya). These three sheaths together constitute the Subtle Body.",
      commentaryNotes: "The foundational mapping of the internal psycho-physical organism in Advaita Vedānta."
    },
    {
      id: "vs-14",
      number: "Section 14",
      title: "Macrocosmic and Microcosmic Subtle Bodies: Sūtrātmā / Hiraṇyagarbha and Taijasa in Dream State",
      mulaSanskrit: `अत्राप्यखिलसूक्ष्मशरीरमेकबुद्धिविषयतया वनवज्जलाशयवद्वा समष्टिरनेकबुद्धिविषयतया वृक्षवज्जलवद्वा व्यष्टिरपि भवति । एतत्समष्ट्युपहितं चैतन्यं सूत्रात्मा हिरण्यगर्भः प्राणश्चेत्युच्यते सर्वत्रानुस्यूतत्वाज्ज्ञानेच्छाक्रियाशक्तिमदुपहितत्वाच्च । अस्यैषा समष्टिः स्थूलप्रपञ्चापेक्षया सूक्ष्मत्वात्सूक्ष्मशरीरं विज्ञानमयादिकोशत्रयं जाग्रद्वासनामयत्वात्स्वप्नोऽत एव स्थूलप्रपञ्चलयस्थानमिति चोच्यते ।

एतद्व्यष्ट्युपहितं चैतन्यं तैजसो भवति तेजोमयान्तःकरणोपहितत्वात् । अस्यापीयं व्यष्टिः स्थूलशरीरापेक्षया सूक्ष्मत्वादिति हेतोरेव सूक्ष्मशरीरं विज्ञानमयादिकोशत्रयं जाग्रद्वासनामयत्वात्स्वप्नोऽतएव स्थूलशरीरलयस्थानमिति चोच्यते । एतौ सूत्रात्मतैजसौ तदानीं मनोवृत्तिभिः सूक्ष्मविषयाननुभवतः 'प्रविविक्तभुक्तैजसः' (मां. उ. ४) इत्यदिश्रुतेः । अत्रापि समष्टिव्यष्ट्योः तदुपहितसूत्रात्मतैजसयोः वनवृक्षवत्तदवच्छिन्नाकाशवच्च जलाशयजलवत्तद्गतप्रतिबिम्बाकाशवच्च अभेदः । एवं सूक्ष्मशरीरोत्पत्तिः ॥ १४ ॥`,
      mulaIast: "atrāpy akhilasūkṣmaśarīram ekabuddhiviṣayatayā vanavaj jalaśayavad vā samaṣṭir... etat-samaṣṭy-upahitaṁ caitanyaṁ sūtrātmā hiraṇyagarbhaḥ prāṇaś cety ucyate... etad-vyaṣṭy-upahitaṁ caitanyaṁ taijaso bhavati... etau sūtrātmataijasau tadānīṁ manovṛttibhiḥ sūkṣmaviṣayān anubhavataḥ... || 14 ||",
      padaccheda: "अत्र, अपि, अखिल-सूक्ष्म-शरीरम्, एक-बुद्धि-विषयतया, वनवत्, जलाशयवत्, वा, समष्टिः ...",
      anvaya: "अखिलसूक्ष्मशरीरसमष्ट्युपहितं चैतन्यं सूत्रात्मा हिरण्यगर्भः प्राणश्चोच्यते । व्यष्ट्युपहितं तु तैजसः । एतौ च स्वप्नावस्थायामनुस्यूतौ ।",
      bhashyaExtract: "समष्टिसूक्ष्मशरीरोपहितो हिरण्यगर्भः, व्यष्ट्युपहितस्तैजसः । उभयोः स्वप्नावस्थायां सूक्ष्मप्रपञ्चानुभवः ।",
      englishTranslation: "Here also, the totality of subtle bodies, regarded collectively as a unit, is a collective whole (Samaṣṭi) like a forest or reservoir; regarded as many, it is individual (Vyaṣṭi) like trees or water droplets. Consciousness conditioned by this collective subtle body is termed Sūtrātmā ('The Thread-Soul'), Hiraṇyagarbha ('The Golden Womb'), and Prāṇa, because it is threaded through all and conditioned by the powers of knowledge, will, and action. Consciousness conditioned by the individual subtle body is termed Taijasa ('The Luminous'), because it is conditioned by the luminous internal organ. Both Sūtrātmā and Taijasa experience subtle objects through mental modifications in the Dream State (Svapnāvasthā), as declared: 'Taijasa is the enjoyer of subtle objects' (Māṇḍūkya 4). Between the collective and individual subtle bodies, and between Sūtrātmā and Taijasa, there is essential non-difference, just like the forest and trees.",
      commentaryNotes: "Demonstrates the identity of individual dream consciousness (Taijasa) with the cosmic intelligence (Hiraṇyagarbha)."
    },
    {
      id: "vs-15",
      number: "Section 15",
      title: "The Quinquipartition Process of Gross Elements (Pañcīkaraṇa-Prakriyā)",
      mulaSanskrit: `स्थूलभूतानि तु पञ्चीकृतानि । पञ्चीकरणं त्वाकाशादिपञ्चस्वेकैकं द्विधा समं विभज्य तेषु दशसु भागेषु प्राथमिकान्पञ्चभागान्प्रत्येकं चतुर्धा समं विभज्य तेषां चतुर्णां भागानां स्वस्वद्वितीयार्धभागपरित्यागेन भागान्तरेषु योजनम् । तदुक्तम् -

'द्विधा विधाय चैकैकं चतुर्धा प्रथमं पुनः ।
स्वस्वेतरद्वितीयांशैर्योजनात्पञ्च पञ्चते ॥' इति ।

अस्याप्रामाण्यं नाशङ्कनीयं त्रिवृत्करणश्रुतेः पञ्चीकरणस्याप्युपलक्षणत्वात् । पञ्चानां पञ्चात्मकत्वे समानेऽपि तेषु च 'वैशेष्यात्तु तद्वादस्तद्वादः' (ब्र. सू. २ । ४ । २२) इति न्यायेनाकाशादिव्यपदेशः सम्भवति । तदानीमाकाशे शब्दोऽभिव्यज्यते वायौ शब्दस्पर्शावग्नौ शब्दस्पर्शरूपाण्यप्सु शब्दस्पर्शरूपरसाः पृथिव्यां शब्दस्पर्शरूपरसगन्धाश्च ॥ १५ ॥`,
      mulaIast: `sthūlabhūtāni tu pañcīkṛtāni | pañcīkaraṇaṁ tv ākāśādipañcasv ekaikaṁ dvidhā samaṁ vibhajya teṣu daśasu bhāgeṣu prāthamikān pañcabhāgān pratyekaṁ caturdhā samaṁ vibhajya teṣāṁ caturṇāṁ bhāgānāṁ svasvadvitīyārdhabhāgaparityāgena bhāgāntareṣu yojanam... 'dvidhā vidhāya caikaikaṁ caturdhā prathamaṁ punaḥ | svasvetaradvitīyāṁśair yojanāt pañca pañcate ||'... || 15 ||`,
      padaccheda: "स्थूल-भूतानि, तु, पञ्चीकृतानि । पञ्चीकरणम्, तु, आकाशादि-पञ्चसु, एक-एकम्, द्विधा, समम्, विभज्य ...",
      anvaya: "स्थूलभूतानि पञ्चीकृतानि । एकैकं भूतं द्विधा विभज्य पुनश्चतुर्धा विभज्य स्वव्यतिरिक्तभागेषु योजनेन पञ्चीकरणं भवति ।",
      bhashyaExtract: "यद्यपि श्रुतौ त्रिवृत्करणमेवोक्तं तथापि तदुपलक्षणं पञ्चीकरणस्य । सर्वभूतेषु पञ्चानां सद्भावेऽपि वैशेष्यात्तु तत्तन्नामव्यपदेशः ।",
      englishTranslation: "The gross elements, however, are compounded through quinquipartition (Pañcīkaraṇa). Quinquipartition consists in dividing each of the five subtle elements equally into two halves; keeping five of the halves aside, dividing each of the other five halves into four equal parts (one-eighth each); and combining each one-eighth part with the other four elements, excluding its own second half. As stated: 'Dividing each element into two, and then dividing the first half into four parts, and combining each with the other four second-halves, each element becomes fivefold.' The validity of this is not to be questioned, because the Śruti passage on tripartite division (Trivṛtkaraṇa in Chāndogya) is an indicative illustration (Upalakṣaṇa) for quinquipartition. Although all five gross elements contain all five components equally, their distinctive names (Space, Air, Fire, Water, Earth) are maintained due to the preponderance of their principal component, as per Brahma Sūtra 2.4.22 ('Because of preponderance, there is that denomination').",
      commentaryNotes: "The classical mathematical formulation of Pañcīkaraṇa explaining how sensory qualities accumulate progressively up to the fivefold quality of Earth."
    },
    {
      id: "vs-16",
      number: "Section 16",
      title: "Creation of the Fourteen Worlds, Cosmic Egg, and Fourfold Gross Bodies",
      mulaSanskrit: `एतेभ्यः पञ्चीकृतेभ्यो भूतेभ्यो भूर्भुवःस्वर्महर्जनस्तपःसत्यमित्येतन्नामकानाम् उपर्युपरिविद्यमानानाम् अतलवितलसुतलरसातलतलातलमहातलपातालनामकानाम् अधोऽधोविद्यमानानां लोकानां ब्रह्माण्डस्य तदन्तर्गतचतुर्विधस्थूलशरीराणां तदुचितानामन्नपानादीनां चोत्पत्तिर्भवति ।

चतुर्विधशरीराणि तु जरायुजाण्डजस्वेदजोद्भिज्जाख्यानि । जरायुजानि जरायुभ्यो जातानि मनुष्यपश्वादीनि । अण्डजान्यण्डेभ्यो जातानि पक्षिपन्नगादीनि । स्वेदजानि स्वेदेभ्यो जातानि यूकमशकादीनि । उद्भिज्जानि भूमिमुद्भिद्य जातानि लतावृक्षादीनि ॥ १६ ॥`,
      mulaIast: "etebhyaḥ pañcīkṛtebhyo bhūtebhyo bhūrbhuvaḥsvar-mahar-janas-tapaḥ-satyam ity etannāmakānām uparyupari vidyamānānām atala-vitala-sutala-rasātala-talātala-mahātala-pātāla-nāmakānām adho'dho vidyamānānāṁ lokānāṁ brahmāṇḍasya... caturvidhaśarīrāṇi tu jarāyujāṇḍajasvedajodbhijjākhyāni... || 16 ||",
      padaccheda: "एतेभ्यः, पञ्चीकृतेभ्यः, भूतेभ्यः, भूर्भुवःस्वः... लोकानाम्, ब्रह्माण्डस्य, चतुर्विध-स्थूल-शरीराणाम्, च, उत्पत्तिः, भवति ...",
      anvaya: "एतेभ्यः पञ्चीकृतेभ्यो भूतेभ्यश्चतुर्दशभुवनानि ब्रह्माण्डं चतुर्विधस्थूलशरीराणि चोत्पद्यन्ते । जरायुजाण्डजस्वेदजोद्भिज्जानि चतुर्विधानि शरीराणि ।",
      bhashyaExtract: "पञ्चीकृतभूतेभ्य एव समष्टिरूपं ब्रह्माण्डं व्यष्टिरूपं चतुर्विधशरीरजातं च जायते ।",
      englishTranslation: "From these quinquipartite gross elements are produced: the higher worlds situated one above another (Bhūḥ, Bhuvaḥ, Svaḥ, Mahaḥ, Janaḥ, Tapaḥ, and Satyam); the nether worlds situated one below another (Atala, Vitala, Sutala, Rasātala, Talātala, Mahātala, and Pātāla); the Cosmic Egg (Brahmāṇḍa); and within it, the four classes of gross bodies along with their appropriate food and drink. The four classes of bodies are: womb-born (Jarāyuja) such as humans and cattle; egg-born (Aṇḍaja) such as birds and serpents; moisture-born (Svedaja) such as lice and mosquitoes; and earth-born (Udbhijja) such as trees, creepers, and plants.",
      commentaryNotes: "Details the traditional cosmological architecture of the fourteen lokas and the fourfold taxonomy of biological embodiment."
    },
    {
      id: "vs-17",
      number: "Section 17",
      title: "Macrocosmic and Microcosmic Gross Bodies: Vaiśvānara / Virāṭ and Viśva in the Waking State",
      mulaSanskrit: `अत्रापि चतुर्विधसकलस्थूलशरीरमेकानेकबुद्धिविषयतया वनवज्जलाशयवद्वा समष्टिर्वृक्षवज्जलवद्वा व्यष्टिरपि भवति । एतत्समष्ट्युपहितं चैतन्यं वैश्वानरो विराडित्युच्यते सर्वनराभिमानित्वाद्विविधं राजमानत्वाच्च । अस्यैषा समष्टिः स्थूलशरीरमन्नविकारत्वादन्नमयकोशः स्थूलभोगायतनत्वाच्च स्थूलशरीरं जाग्रदिति च व्यपदिश्यते ।

एतद्व्यष्ट्युपहितं चैतन्यं विश्व इत्युच्यते सूक्ष्मशरीराभिमानमपरित्यज्य स्थूलशरीरादिप्रविष्टत्वात् । अस्याप्येषा व्यष्टिः स्थूलशरीरमन्नविकारत्वादेव हेतोरन्नमयकोशो जाग्रदिति चोच्यते ।

तदानीमेतौ विश्ववैश्वानरौ दिग्वातार्कवरुणाश्विभिः क्रमान्नियन्त्रितेन श्रोत्रादीन्द्रियपञ्चकेन क्रमाच्छब्दस्पर्शरूपरसगन्धानग्नीन्द्रोपेन्द्रयमप्रजापतिभिः क्रमान्नियन्त्रितेन वागादीन्द्रियपञ्चकेन क्रमाद्वचनादानगमनविसर्गानन्दान् चन्द्रचतुर्मुखशङ्कराच्युतैः क्रमान्नियन्त्रितेन मनोबुद्ध्यहङ्कारचित्ताख्येनान्तरेन्द्रियचतुष्केण क्रमात्सङ्कल्पनिश्चयाहङ्कार्यचैत्तांश्च सर्वानेतान् स्थूलविषयाननुभवतः 'जागरितस्थानो बहिःप्रज्ञः' (मां. उ. ३) इत्यादिश्रुतेः । अत्राप्यनयोः स्थूलव्यष्टिसमष्ट्योस्तदुपहितविश्ववैश्वानरयोश्च वनवृक्षवत्तदवच्छिन्नाकाशवच्च जलाशयजलवत्तद्गतप्रतिबिम्बाकाशवच्च पूर्ववदभेदः । एवं पञ्चीकृतपञ्चभूतेभ्यः स्थूलप्रपञ्चोत्पत्तिः ॥ १७ ॥`,
      mulaIast: `atrāpi caturvidhasakalasthūlaśarīram ekānekabuddhiviṣayatayā... etat-samaṣṭy-upahitaṁ caitanyaṁ vaiśvānaro virāḍ ity ucyate... etad-vyaṣṭy-upahitaṁ caitanyaṁ viśva ity ucyate... tadānīm etau viśvavaiśvānarau... sarvān etān sthūlaviṣayān anubhavataḥ 'jāgaritasthāno bahiḥprajñaḥ' ityādi-śruteḥ... || 17 ||`,
      padaccheda: "अत्र, अपि, चतुर्विध-सकल-स्थूल-शरीरम्, समष्टिः, व्यष्टिः, अपि, भवति । समष्टि-उपहितम्, चैतन्यम्, वैश्वानरः, विराट्, इति, उच्यते ... व्यष्टि-उपहितम्, तु, विश्वः, इति ...",
      anvaya: "सकलस्थूलशरीरसमष्ट्युपहितं चैतन्यं वैश्वानरो विराडित्युच्यते । व्यष्ट्युपहितं तु विश्व इत्युच्यते । एतौ जागरितस्थानौ बहिःप्रज्ञौ स्थूलविषयाननुभवतः ।",
      bhashyaExtract: "स्थूलसमष्ट्युपहितो विराड्, व्यष्ट्युपहितो विश्वः । उभयोरपि जाग्रदवस्थायामन्नमयकोशाभिमानेन स्थूलभोगः ।",
      englishTranslation: "Here too, the totality of gross bodies is collectively a unit (Samaṣṭi) like a forest, and individually manifold (Vyaṣṭi) like trees. Consciousness conditioned by this collective gross body is termed Vaiśvānara and Virāṭ, because it identifies with all humans and shines forth in diverse forms. Its limiting adjunct is the gross body, named the Food Sheath (Annamayakośa) because it is transformed from food, and the Waking State (Jāgrat) because it is the locus of gross experiences. Consciousness conditioned by the individual gross body is termed Viśva, because, without relinquishing identification with the subtle body, it enters the gross body. In the waking state, both Viśva and Vaiśvānara experience gross external sounds, sights, touches, tastes, and smells through the sense-organs governed by their presiding cosmic deities (Dig-Devatās, Vāyu, Sūrya, Varuṇa, Aśvins, Agni, Indra, Upendra, Yama, Prajāpati, Candra, Brahmā, Śaṅkara, Acyuta), as declared: 'Having the waking state as its sphere, cognizing outward objects' (Māṇḍūkya 3). Here too, the identity of Viśva and Vaiśvānara is non-different, like the forest-enclosed sky and tree-enclosed sky.",
      commentaryNotes: "Connects the microcosmic individual waking self (Viśva) with the universal macrocosmic body (Virāṭ) through presiding devatās."
    },
    {
      id: "vs-18",
      number: "Section 18",
      title: "Cosmic Integration: 'Sarvaṁ Khalvidaṁ Brahma' and General Adhyāropa Summary",
      mulaSanskrit: `एतेषां स्थूलसूक्ष्मकारणप्रपञ्चानामपि समष्टिरेको महान् प्रपञ्चो भवति यथा अवान्तरवनानां समष्टिरेकं महद्वनं भवति यथा वावान्तरजलाशयानां समष्टिरेको महान् जलाशयः । एतदुपहितं वैश्वानरादीश्वरपर्यन्तं चैतन्यमपि अवान्तरवनावच्छिन्नाकाशवदवान्तरजलाशयगतप्रतिबिम्बाकाशवच्च एकमेव । आभ्यां महाप्रपञ्चतदुपहितचैतन्याभ्यां तप्तायःपिण्डवदविविक्तं सदनुपहितं चैतन्यं 'सर्वं खल्विदं ब्रह्म' (छा. उ. ३ । १४ । १) इति (महा)वाक्यस्य वाच्यं भवति विविक्तं सल्लक्ष्यमपि भवति । एवं वस्तुन्यवस्त्वारोपोऽध्यारोपः सामान्येन प्रदर्शितः ॥ १८ ॥`,
      mulaIast: "eteṣāṁ sthūlasūkṣmakāraṇaprapañcānām api samaṣṭir eko mahān prapañco bhavati... etad-upahitaṁ vaiśvānarādīśvaraparyantaṁ caitanyam api... ekam eva | ābhyāṁ mahāprapañcatadupahitacaitanyābhyāṁ taptāyaḥpiṇḍavad aviviktaṁ sad anupahitaṁ caitanyaṁ 'sarvaṁ khalv idaṁ brahma' iti vākyasya vācyaṁ bhavati viviktaṁ sal lakṣyam api bhavati | evaṁ vastuny avastvāropo'dhyāropaḥ sāmānyena pradarśitaḥ || 18 ||",
      padaccheda: "एतेषाम्, स्थूल-सूक्ष्म-कारण-प्रपञ्चानाम्, अपि, समष्टिः, एकः, महान्, प्रपञ्चः, भवति ...",
      anvaya: "स्थूलसूक्ष्मकारणप्रपञ्चानां समष्टिरेको महान् प्रपञ्चो भवति । एतदुपहितं चैतन्यमेकमेव । अविविक्तं सत् 'सर्वं खल्विदं ब्रह्म' इति वाक्यस्य वाच्यम्, विविक्तं सल्लक्ष्यम् । एवमध्यारोपः प्रदर्शितः ।",
      bhashyaExtract: "सर्वस्यापि कार्यजातस्य ब्रह्मविवर्तत्वेन तदतिरेकेणाभावान् 'सर्वं खल्विदं ब्रह्म' इति सामानाधिकरण्योपपत्तिः ।",
      englishTranslation: "The collective sum of these gross, subtle, and causal universes forms one vast Great Cosmic Universe (Mahā-Prapañca), just as the collective sum of intermediate forests forms one great forest, or intermediate bodies of water form an ocean. The Consciousness conditioned by this, ranging from Vaiśvānara up to Īśvara, is likewise one. Unconditioned Consciousness, when undiscriminated from this vast universe and conditioned consciousness like a red-hot iron ball, is the expressed meaning (Vācyārtha) of the Great Dictum 'All this is indeed Brahman' (Chāndogya 3.14.1); when thoroughly discriminated, it is the indicated reality (Lakṣyārtha). Thus has deliberate superimposition (Adhyāropa) of the unreal upon the Real been comprehensively demonstrated.",
      commentaryNotes: "Concludes the cosmic Adhyāropa section, reconciling the famous Chāndogya dictum 'Sarvaṁ Khalvidaṁ Brahma' via the Taptāyaḥ-piṇḍa metaphor."
    }
  ]
};

// =========================================================================================
// CHAPTER 4: DEHĀTMA-VĀDA-NIRĀSA & APAVĀDA-PRAKRIYĀ (Sections 19 - 21)
// =========================================================================================
export const VEDANTASARA_CHAPTER_4: GranthaChapter = {
  id: "vs-adhyaya-4",
  chapterTitle: "Chapter 4: Dehātma-Vāda-Nirāsa & Apavāda-Prakriyā",
  chapterTitleSanskrit: "चतुर्थोऽध्यायः — देहात्मवादनिर्रासः अपवादप्रक्रिया च",
  summary:
    "Systematic refutation of the mistaken identifications of the Self (Dehātma-Vādas) by naive worldly men, Cārvākas, Buddhists, and ritualists; establishing the witness Consciousness beyond all sheaths; and the doctrine of Sublation (Apavāda-Prakriyā) resolving phenomenal effects back into their non-dual substratum.",
  verses: [
    {
      id: "vs-19",
      number: "Section 19",
      title: "False Identifications of the Self by Worldly Men, Cārvākas, Buddhists, and Mīmāṁsakas",
      mulaSanskrit: `इदानीं प्रत्यगात्मनि इदमिदमयमयमारोपयतीति विशेषत उच्यते । अतिप्राकृतस्तु 'आत्मा वै जायते पुत्रः' इत्यादिश्रुतेः स्वस्मिन्निव पुत्रेऽपि प्रेमदर्शनात्पुत्रे पुष्टे नष्टे चाहमेव पुष्टो नष्टश्चेत्याद्यनुभवाच्च पुत्र आत्मेति वदति ।

चार्वाकस्तु 'स वा एष पुरुषोऽन्नरसमयः' (तै. उ. २ । १ । १) इत्यादिश्रुतेः प्रदीप्तगृहात्स्वपुत्रं परित्यज्यापि स्वस्य निर्गमदर्शनात्स्थूलोऽहं कृशोऽहमित्याद्यनुभवाच्च स्थूलशरीरमात्मेति वदति ।

अपरश्चार्वाकः 'ते ह प्राणाः प्रजापतिं पितरमेत्योचुः' (छा. उ. ५ । १ । ७) इत्यादिश्रुतेः इन्द्रियाणामभावे शरीरचलनाभावात्काणोऽहं बधिरोऽहमित्याद्यनुभवाच्च इन्द्रियाण्यात्मेति वदति ।

अपरश्चार्वाकः 'अन्योऽन्तर आत्मा प्राणमयः' (तै. उ. २ । २ । १) इत्यादिश्रुतेः प्राणाभाव इन्द्रियादिचलनायोगात्‌ अहमशनायावानहं पिपासावानित्याद्यनुभवाच्च प्राण आत्मेति वदति ।

अन्यस्तु चार्वाकः 'अन्योऽन्तर आत्मा मनोमयः' (तै. उ. २ । ३ । १) इत्यादिश्रुतेः मनसि सुप्ते प्राणादेरभावादहं सङ्कल्पवानहं विकल्पवानित्याद्यनुभवाच्च मन आत्मेति वदति ।

बौद्धस्तु 'अन्योऽन्तर आत्मा विज्ञानमयः' (तै. उ. २ । ४ । १) इत्यादिश्रुतेः कर्तुरभावे करणस्य शक्त्यभावादहं कर्ताहं भोक्तेत्याद्यनुभवाच्च बुद्धिरात्मेति वदति ।

प्राभाकरतार्किकौ तु 'अन्योऽन्तर आत्मानन्दमयः' (तै. उ. २ । ५ । १) इत्यादिश्रुतेः बुद्ध्यादीनामज्ञाने लयदर्शनादहमज्ञोऽहमज्ञानीत्याद्यनुभवाच्च अज्ञानमात्मेति वदतः ।

भाट्टस्तु 'प्रज्ञानघन एवानन्दमयः' (मां. उ. ५) इत्यादिश्रुतेः सुषुप्तौ प्रकाशाप्रकाशसद्भावान्मामहं न जानामीत्याद्यनुभवाच्च अज्ञानोपहितं चैतन्यमात्मेति वदति ।

अपरो बौद्धः 'असदेवेदमग्र आसीत्' (छा. उ. ६ । २ । १) इत्यादिश्रुतेः सुषुप्तौ सर्वाभावादहं सुषुप्तौ नासमित्युत्थितस्य स्वाभावपरामर्शविषयानुभवाच्च शून्यमात्मेति वदति ॥ १९ ॥`,
      mulaIast: `idānīṁ pratyagātmani idam idam ayam ayam āropayatīti viśeṣata ucyate | atiprākṛtas tu 'ātmā vai jāyate putraḥ'... cārvākas tu sthūlaśarīram ātmā... aparaś cārvāka indriyāṇi... aparaḥ prāṇaḥ... anyaḥ manaḥ... bauddhas tu buddhiḥ... prābhākaratārkikau tu ajñānam... bhāṭṭas tu ajñānopahitaṁ caitanyam... aparo bauddhaḥ śūnyam ātmā... || 19 ||`,
      padaccheda: "इदानीम्, प्रत्यगात्मनि, इदम्, इदम्, अयम्, अयम्, आरोपयति, इति, विशेषतः, उच्यते ...",
      anvaya: "अतिप्राकृतः पुत्रमात्मेति वदति । चार्वाकः स्थूलशरीरम्, अपरो हीन्द्रियाणि, अपरो प्राणम्, अन्यो मन आत्मेति वदति । बौद्धो बुद्धिम्, प्राभाकरतार्किकौ त्वज्ञानम्, भाट्टोऽज्ञानोपहितचैतन्यम्, अपरो बौद्धः शून्यमात्मेति वदति ।",
      bhashyaExtract: "पुत्रादारभ्य शून्यपर्यन्तं सर्वेऽपि वादा आत्मत्वभ्रान्तिविजृम्भिताः । यतो यत उत्तरोत्तरश्रुत्या पूर्वपूर्वबाधः क्रियते ।",
      englishTranslation: "Now is described in detail the erroneous superimpositions placed upon the innermost Self by various schools: The unrefined worldly man (Atiprākṛta) asserts that his son is the Self, citing 'The Self is verily born as the son' and loving his son as himself. The first Cārvāka claims the gross physical body is the Self, citing 'He is made of the essence of food' and feeling 'I am stout, I am thin.' The second Cārvāka asserts the sense-organs are the Self, for without senses the body does not function, feeling 'I am blind, I am deaf.' The third Cārvāka asserts the vital breath (Prāṇa) is the Self, feeling 'I am hungry, I am thirsty.' The fourth Cārvāka claims the mind (Manas) is the Self, feeling 'I resolve, I doubt.' The Buddhist (Yogācāra) asserts the intellect (Buddhi / momentary consciousness) is the Self, feeling 'I am the agent, I am the enjoyer.' The Prābhākara Mīmāṁsaka and the Naiyāyika assert that Ignorance is the Self, feeling 'I am ignorant.' The Bhāṭṭa Mīmāṁsaka asserts that Consciousness veiled by Ignorance is the Self, feeling 'I do not know myself.' Another Buddhist (Mādhyamika) asserts that the Void (Śūnya / Absolute Non-existence) is the Self, citing 'In the beginning this was non-existent alone' and the memory upon waking: 'I did not exist in deep sleep.'",
      commentaryNotes: "Famous doxographical survey summarizing the gradation of false self-identifications from external objects down to nihilistic void."
    },
    {
      id: "vs-20",
      number: "Section 20",
      title: "Refutation of all False Identifications from Son to Void: Pratyak-Caitanya Established",
      mulaSanskrit: `एतेषां पुत्रादीनाम् अनात्मत्वमुच्यते । एतैः अतिप्राकृतादिवादिभिरुक्तेषु श्रुतियुक्त्यनुभवाभासेषु पूर्वपूर्वोक्तश्रुतियुक्त्यनुभवाभासानामुत्तरोत्ततरश्रुतियुक्त्यनुभवाभासैः आत्मत्वबाधदर्शनात्पुत्रादीनामनात्मत्वं स्पष्टमेव ।

किञ्च 'प्रत्यगस्थूलोऽचक्षुरप्राणोऽमना अकर्ता चैतन्यं चिन्मात्रं सत्' इत्यादिप्रबलश्रुतिविरोधादस्य पुत्रादिशून्यपर्यन्तस्य जडस्य चैतन्यभास्यत्वेन घटादिवदनित्यत्वादहं ब्रह्मेति विद्वदनुभवप्राबल्याच्च तत्तच्छ्रुतियुक्त्यनुभवाभासानां बाधितत्वादपि पुत्रादिशून्यपर्यन्तमखिलमनात्मैव । अतस्तत्तद्भासकं नित्यशुद्धबुद्धमुक्तसत्यस्वभावं प्रत्यक्चैतन्यमेवात्मवस्त्विति वेदान्तविद्वदनुभवः । एवमध्यारोपः ॥ २० ॥`,
      mulaIast: `eteṣāṁ putrādīnām anātmatvam ucyate | etair atiprākṛtādivādibhir ukteṣu śrutiyuktyanubhavābhāseṣu pūrvapūrvoktaśrutiyuktyanubhavābhāsānām uttarottaraśrutiyuktyanubhavābhāsair ātmatvabādhadarśanāt putrādīnām anātmatvaṁ spaṣṭam eva... ataḥ tat-tad-bhāsakaṁ nityaśuddhabuddhamuktasatyasvabhāvaṁ pratyakcaitanyam evātmavastv iti vedāntavidvadanubhavaḥ | evam adhyāropaḥ || 20 ||`,
      padaccheda: "एतेषाम्, पुत्रादीनाम्, अनात्मत्वम्, उच्यते ...",
      anvaya: "पुत्रादिशून्यपर्यन्तं सर्वमनात्मैव, जडत्वात् दृश्यत्वात् घटवदनित्यत्वाच्च । तत्तद्भासकं नित्यशुद्धबुद्धमुक्तस्वभावं प्रत्यक्चैतन्यमेवात्मवस्त्विति सिद्धम् ।",
      bhashyaExtract: "यद् दृश्यं तज्जडं घटादिवदनित्यम् । पुत्रादिशून्यपर्यन्ताः सर्वे दृश्यभावाः । दृग्रूपं चैतन्यमेव सत्यमात्मा ।",
      englishTranslation: "Now the non-Self nature (Anātmatva) of these—from son to the void—is demonstrated. In the fallacious scriptures, arguments, and experiences cited by these disputants, each preceding view is refuted by the succeeding one; hence their non-Self nature is evident. Furthermore, all these entities from son to void are insentient (Jaḍa), illumined by Consciousness, and therefore transient like a clay pot, directly contradicted by the supreme Śrutis declaring: 'The innermost Self is unattached, neither stout, nor having eyes, breath, or mind, non-agent, Pure Consciousness, Existence itself.' Moreover, they are sublated by the enlightened direct experience 'I am Brahman.' Therefore, the Witness Consciousness which illumines all of them, eternally pure, conscious, liberated, and of the nature of absolute Reality (Pratyak-Caitanya), is alone the true Self. Such is the realization of the wise masters of Vedānta. Thus ends the demonstration of Superimposition (Adhyāropa).",
      commentaryNotes: "Applies the Dṛg-Dṛśya-Viveka principle: whatever is seen or known (object) is insentient non-Self; the Seer alone is the unslayable Self."
    },
    {
      id: "vs-21",
      number: "Section 21",
      title: "Sublation (Apavāda): Vivarta vs. Pariṇāma and Dissolution into Turīya Brahman",
      mulaSanskrit: `अपवादो नाम रज्जुविवर्तस्य सर्पस्य रज्जुमात्रत्ववत् वस्तुविवर्तस्यावस्तुनोऽज्ञानादेः प्रपञ्चस्य वस्तुमात्रत्वम् । तदुक्तम् -

'सतत्त्वतोऽन्यथाप्रथा विकार इत्युदीरितः ।
अतत्त्वतोऽन्यथाप्रथा विवर्त इत्युदीरितः ॥' इति ।

तथाहि एतद्भोगायतनं चतुर्विधसकलस्थूलशरीरजातं भोग्यरूपान्नपानादिकम् एतदायतनभूतभूरादिचतुर्दशभुवनानि एतदायतनभूतं ब्रह्माण्डं चैतत्सर्वमेतेषां कारणरूपं पञ्चीकृतभूतमात्रं भवति । एतानि शब्दादिविषयसहितानि पञ्चीकृतानि भूतानि सूक्ष्मशरीरजातं चैतत्सर्वमेतेषां कारणरूपापञ्चीकृतभूतमात्रं भवति । एतानि सत्त्वादिगुणसहितान्यपञ्चीकृतान्युत्पत्तिव्युत्क्रमेणैतत्कारणभूताज्ञानोपहितचैतन्यमात्रं भवति । एतदज्ञानमज्ञानोपहितं चैतन्यं चेश्वरादिकमेतदाधारभूतानुपहितचैतन्यरूपं तुरीयं ब्रह्ममात्रं भवति ॥ २१ ॥`,
      mulaIast: `apavādo nāma rajjuvivartasya sarpasya rajjumātratvavat vastuvivartasyāvastuno'jñānādeḥ prapañcasya vastumātratvam | taduktam - 'satattvato'nyathāprathā vikāra ityudīritaḥ | atattvato'nyathāprathā vivarta ityudīritaḥ ||' iti... || 21 ||`,
      padaccheda: "अपवादः, नाम, रज्जु-विवर्तस्य, सर्पस्य, रज्जु-मात्रत्ववत्, वस्तु-विवर्तस्य, अवस्तुनः, अज्ञानादेः, प्रपञ्चस्य, वस्तु-मात्रत्वम् ...",
      anvaya: "अपवादो नाम रज्जुविवर्तस्य सर्पस्य रज्जुमात्रत्ववत् वस्तुविवर्तस्य प्रपञ्चस्य वस्तुमात्रत्वम् । सर्वं कार्यं कारणे विलीने सति तुरीयं ब्रह्ममात्रमवशिष्यते ।",
      bhashyaExtract: "विकारः परिणामः क्षीरादेर्दधिरूपेणेव । विवर्तस्तु भ्रान्त्या अन्यथाभानं रज्जाविव सर्पस्य । प्रपञ्चो ब्रह्मणो विवर्तः, अतो ज्ञानाद्ब्रह्ममात्रमेवावशिष्यते ।",
      englishTranslation: "Sublation (Apavāda) is the realization that the unreal universe—originating from ignorance and being an illusory appearance (Vivarta) of the Real—is nothing other than the Real itself; just as the snake, which is an illusory appearance of the rope, is recognized as being nothing other than the rope. As it is said: 'An actual transformation into another state of reality is called Pariṇāma (Modification); whereas an apparent transformation into an unreal appearance is called Vivarta (Illusory Appearance).' Accordingly: the gross bodies, food, the fourteen worlds, and the cosmic egg resolve into their cause—the quinquipartite gross elements; these gross elements and the subtle bodies resolve into the uncompounded subtle elements; these subtle elements with their Guṇas resolve in reverse order into Consciousness conditioned by Ignorance; and this ignorance together with conditioned consciousness resolves into that very unconditioned Consciousness—Turīya Brahman alone.",
      commentaryNotes: "Provides the definitive definition distinguishing Vivartavāda from Pariṇāmavāda, tracing the cosmic involution back to its source."
    }
  ]
};

// =========================================================================================
// CHAPTER 5: PADĀRTHA-ŚODHANA & MAHĀVĀKYA-VICĀRA (Sections 22 - 27)
// =========================================================================================
export const VEDANTASARA_CHAPTER_5: GranthaChapter = {
  id: "vs-adhyaya-5",
  chapterTitle: "Chapter 5: Padārtha-Śodhana & Mahāvākya-Vicāra",
  chapterTitleSanskrit: "पञ्चमोऽध्यायः — पदार्थशोधनं महावाक्यविचारश्च",
  summary:
    "Purification of the literal (Vācyārtha) and indicated (Lakṣyārtha) meanings of 'Tat' and 'Tvam'; the threefold relational syntax (Sambandha-traya) of 'Tat Tvam Asi'; refutation of literal contact (Saṁsarga) and qualified identity (Viśiṣṭa); refutation of Jahal-lakṣaṇā and Ajahal-lakṣaṇā; and the triumph of Jahadajahallakṣaṇā (Bhāga-Tyāga-Lakṣaṇā).",
  verses: [
    {
      id: "vs-22",
      number: "Section 22",
      title: "Purification of the Words 'Tat' (That) and 'Tvam' (Thou)",
      mulaSanskrit: `आभ्यामध्यारोपापवादाभ्यां तत्त्वम्पदार्थशोधनमपि सिद्धं भवति । तथाहि - अज्ञानादिसमष्टिरेतदुपहितं सर्वज्ञत्वादिविशिष्टं चैतन्यम् एतदनुपहितं चैतत्त्रयं तप्तायःपिण्डवदेकत्वेनावभासमानं तत्पदवाच्यार्थो भवति । एतदुपाध्युपहिताधारभूतमनुपहितं चैतन्यं तत्पदलक्ष्यार्थो भवति ।

अज्ञानादिव्यष्टिः एतदुपहिताल्पज्ञत्वादिविशिष्टचैतन्यम् एतदनुपहितं चैतत्त्रयं तप्तायःपिण्डवदेकत्वेनावभासमानं त्वम्पदवाच्यार्थो भवति । एतदुपाध्युपहिताधारभूतमनुपहितं प्रत्यगानन्दं तुरीयं चैतन्यं त्वम्पदलक्ष्यार्थो भवति ॥ २२ ॥`,
      mulaIast: "ābhyām adhyāropāpavādābhyāṁ tat-tvam-padārtha-śodhanam api siddhaṁ bhavati... tat-pada-vācyārtho bhavati... tat-pada-lakṣyārtho bhavati... tvam-pada-vācyārtho bhavati... tvam-pada-lakṣyārtho bhavati || 22 ||",
      padaccheda: "आभ्याम्, अध्यारोप-अपवादाभ्याम्, तत्-त्वम्-पदार्थ-शोधनम्, अपि, सिद्धम्, भवति ...",
      anvaya: "समष्ट्यज्ञानोपहितं सर्वज्ञत्वादिगुणकं चैतन्यं तत्पदवाच्यार्थः, अनुपहितं शुद्धचैतन्यं तत्पदलक्ष्यार्थः । व्यष्ट्यज्ञानोपहितमल्पज्ञत्वादिगुणकं चैतन्यं त्वम्पदवाच्यार्थः, प्रत्यगानन्दं शुद्धं चैतन्यं त्वम्पदलक्ष्यार्थः ।",
      bhashyaExtract: "उपाधिसहितं वाच्यार्थः, उपाधिनिर्मुक्तं शुद्धं चैतन्यं लक्ष्यार्थः । अनयोरुपहितयोर्भानं विरोधाद्बाध्यते, शुद्धयोस्त्वैक्यम् ।",
      englishTranslation: "Through these methods of deliberate superimposition and sublation, the clarification of the meanings of the terms 'Tat' (That) and 'Tvam' (Thou) is achieved: The collective ignorance, the consciousness conditioned by it endowed with omniscience, and the unconditioned substratum, appearing together as one like an incandescent iron ball, constitute the expressed meaning (Vācyārtha) of 'Tat'. The unconditioned Consciousness serving as their pure substratum is the indicated meaning (Lakṣyārtha) of 'Tat'. Likewise, the individual ignorance, the consciousness conditioned by it endowed with limited knowledge, and the unconditioned substratum, appearing together as one like a hot iron ball, constitute the expressed meaning (Vācyārtha) of 'Tvam'. The unconditioned, innermost Blissful Consciousness (Turīya) serving as their pure substratum is the indicated meaning (Lakṣyārtha) of 'Tvam'.",
      commentaryNotes: "Lays the groundwork for Mahāvākya exegesis by separating the qualified adjuncts from the underlying pure Consciousness."
    },
    {
      id: "vs-23",
      number: "Section 23",
      title: "The Threefold Relationship in 'Tat Tvam Asi': Sāmānādhikaraṇya, Viśeṣaṇa-Viśeṣyatā, and Lakṣya-Lakṣaṇa",
      mulaSanskrit: `अथ महावाक्यार्थो वर्ण्यते । इदं तत्त्वमसिवाक्यं सम्बन्धत्रयेणाखण्डार्थबोधकं भवति । सम्बन्धत्रयं नाम पदयोः सामानाधिकरण्यं पदार्थयोर्विशेषणविशेष्यभावः प्रत्यगात्मलक्षणयोर्लक्ष्यलक्षणभावश्चेति । तदुक्तम् -

'सामानाधिकरण्यं च विशेषणविशेष्यता ।
लक्ष्यलक्षणसम्बन्धः पदार्थप्रत्यगात्मनाम्॥' इति ।

सामानाधिकरण्यसम्बन्धस्तावद्यथा सोऽयं देवदत्त इत्यस्मिन्वाक्ये तत्कालविशिष्टदेवदत्तवाचकसशब्दस्य एतत्कालविशिष्टदेवदत्तवाचकायंशब्दस्य चैकस्मिन्पिण्डे तात्पर्यसम्बन्धः । तथा च तत्त्वमसीति वाक्येऽपि परोक्षत्वादिविशिष्टचैतन्यवाचकतत्पदस्य अपरोक्षत्वादिविशिष्टचैतन्यवाचकत्वम्पदस्य चैकस्मिंश्चैतन्ये तात्पर्यसम्बन्धः ।

विशेषणविशेष्यभावसम्बन्धस्तु यथा तत्रैव वाक्ये सशब्दार्थतत्कालविशिष्टदेवदत्तस्य अयंशब्दार्थैतत्कालविशिष्टदेवदत्तस्य चान्योन्यभेदव्यावर्तकतया विशेषणविशेष्यभावः । तथात्रापि वाक्ये तत्पदार्थपरोक्षत्वादिविशिष्टचैतन्यस्य त्वम्पदार्थापरोक्षत्वादिविशिष्टचैतन्यस्य चान्योन्यभेदव्यावर्तकतया विशेषणविशेष्यभावः ।

लक्ष्यलक्षणसम्बन्धस्तु यथा तत्रैव सशब्दायंशब्दयोस्तदर्थयोर्वा विरुद्धतत्कालैतत्कालविशिष्टत्वपरित्यागेनाविरुद्धदेवदत्तेन सह लक्ष्यलक्षणभावः । तथात्रापि वाक्ये तत्त्वम्पदयोस्तदर्थयोर्वा विरुद्धपरोक्षत्वापरोक्षत्वादिविशिष्टत्वपरित्यागेनाविरुद्धचैतन्येन सह लक्ष्यलक्षणभावः । इयमेव भागलक्षणेत्युच्यते ॥ २३ ॥`,
      mulaIast: `atha mahāvākyārtho varṇyate | idaṁ tat-tvam-asi-vākyaṁ sambandhatrayeṇākhaṇḍārthabodhakaṁ bhavati | sambandhatrayaṁ nāma padayoḥ sāmānādhikaraṇyaṁ padārthayor viśeṣaṇaviśeṣyabhāvaḥ pratyagātmalakṣaṇayor lakṣyalakṣaṇabhāvaś ceti... iyameva bhāgalakṣaṇety ucyate || 23 ||`,
      padaccheda: "अथ, महावाक्य-अर्थः, वर्ण्यते । इदम्, तत्-त्वम्-असि-वाक्यम्, सम्बन्ध-त्रयेण, अखण्ड-अर्थ-बोधकम्, भवति ...",
      anvaya: "तत्त्वमसिवाक्यं पदयोः सामानाधिकरण्येन, पदार्थयोर्विशेषणविशेष्यभावेन, प्रत्यगात्मलक्षणयोर्लक्ष्यलक्षणभावेन चाखण्डार्थं बोधयति । इयमेव भागलक्षणा ।",
      bhashyaExtract: "पदयोरेकस्मिन्नर्थे पर्यवसानं सामानाधिकरण्यम् । विरुद्धव्यावृत्त्या विशेषणविशेष्यभावः । विरोधांशत्यागेन अविरुद्धांशबोधनं लक्ष्यलक्षणभावः ।",
      englishTranslation: "Now the meaning of the Great Dictum (Mahāvākya) is explained. The sentence 'Tat Tvam Asi' ('That Thou Art') imparts the indivisible non-dual truth (Akhaṇḍārtha) through a threefold relationship: 1. Co-ordinate relation (Sāmānādhikaraṇya) between the words; 2. Mutual qualification (Viśeṣaṇa-viśeṣya-bhāva) between their meanings; and 3. Indicator-indicated relation (Lakṣya-lakṣaṇa-bhāva) between the words and the innermost Self. Just as in the everyday sentence 'This is that Devadatta', the word 'that' referring to Devadatta seen in the past, and 'this' referring to Devadatta seen in the present, point to the identical individual; so in 'That Thou Art', the word 'That' denoting consciousness characterized by remoteness, and 'Thou' denoting consciousness characterized by immediacy, point to the one non-dual Consciousness. Discarding the mutually contradictory attributes of past/present time (or remoteness/immediacy), the essential unconditioned Consciousness alone is revealed. This very method is known as Bhāgalakṣaṇā (Partial Indication).",
      commentaryNotes: "One of the most famous passages in all Vedāntic literature formulating Sambandha-traya and the logic of Akhaṇḍārtha."
    },
    {
      id: "vs-24",
      number: "Section 24",
      title: "Inapplicability of 'Blue Lotus' (Samsarga / Viśiṣṭa) Syntax in 'Tat Tvam Asi'",
      mulaSanskrit: `अस्मिन्वाक्ये नीलमुत्पलमिति वाक्यवद्वाक्यार्थो न सङ्गच्छते । तत्र तु नीलपदार्थनीलगुणस्योत्पलपदार्थोत्पलद्रव्यस्य च शौक्ल्यपटादिभेदव्यावर्तकतय अन्योन्यविशेषणविशेष्यरूपसंसर्गस्य अन्यतरविशिष्टस्यान्यतरस्य तदैक्यस्य वा वाक्यार्थत्वाङ्गीकारे प्रमाणान्तरविरोधाभावात्तद्वाक्यार्थः सङ्गच्छते ।

अत्र तु तत्पदार्थपरोक्षत्वादिविशिष्टचैतन्यस्य त्वम्पदार्थापरोक्षत्वादिविशिष्टचैतन्यस्य चान्योन्यभेदव्यावर्तकतया विशेषणविशेष्यभावसंसर्गस्यान्यतरविशिष्टस्यान्यतरस्य तदैक्यस्य वा वाक्यार्थत्वाङ्गीकारे प्रत्यक्षादिप्रमाणविरोधाद्वाक्यार्थो न सङ्गच्छते । तदुक्तम् -

'संसर्गो वा विशिष्टो वा वाक्यार्थो नात्र सम्मतः ।
अखण्डैकरसत्वेन वाक्यार्थो विदुषां मतः ॥' इति (पञ्चदशी ७ । ७५) ॥ २४ ॥`,
      mulaIast: "asmin vākye nīlam utpalam iti vākyavad vākyārtho na saṅgacchate... 'saṁsargo vā viśiṣṭo vā vākyārtho nātra sammataḥ | akhaṇḍaikarasatvena vākyārtho viduṣāṁ mataḥ ||' iti... || 24 ||",
      padaccheda: "अस्मिन्, वाक्ये, नीलम्, उत्पलम्, इति, वाक्यवत्, वाक्य-अर्थः, न, सङ्गच्छते ...",
      anvaya: "अत्र नीलमुत्पलमिति वाक्यवद् वाक्यार्थो न सम्भवति, परोक्षत्वापरोक्षत्वयोर्विरोधेन संसर्गस्य विशिष्टस्य वाङ्गीकारे प्रत्यक्षविरोधात् । अखण्डैकरसत्वेनैव वाक्यार्थः ।",
      bhashyaExtract: "नीलोत्पलयोर्गुणगुणिनोर्न विरोधः, परन्त्वीश्वरजीवयोः सर्वज्ञत्वाल्पज्ञत्वयोः प्रत्यक्षविरोधः । अतो न विशिष्टैक्यम्, अपि त्वखण्डैक्यम् ।",
      englishTranslation: "In this sentence, the meaning cannot be understood like 'The blue lotus' (Nīlam Utpalam). In 'the blue lotus', the quality 'blue' and the substance 'lotus' qualify each other, excluding whiteness or cloth; admitting a qualified union (Viśiṣṭa) or syntactic contact (Saṁsarga) causes no contradiction with any other means of knowledge. But in 'That Thou Art', if one were to accept a qualified combination of consciousness characterized by remoteness/omniscience with consciousness characterized by immediacy/limited knowledge, it would directly contradict direct perception and logic. As declared: 'Neither syntactic relation (Saṁsarga) nor a qualified entity (Viśiṣṭa) is accepted here as the sentence-meaning; the sentence-meaning held by the wise is indivisible, homogeneous Essence (Akhaṇḍaikarasa)' (Pañcadaśī 7.75).",
      commentaryNotes: "Refutes Rāmānuja's Viśiṣṭādvaita interpretation of Sāmānādhikaraṇya as Viśiṣṭa-Aikya, upholding Akhaṇḍārtha."
    },
    {
      id: "vs-25",
      number: "Section 25",
      title: "Inapplicability of Exclusive Indication (Jahal-Lakṣaṇā)",
      mulaSanskrit: `अत्र गङ्गायां घोषः प्रतिवसति इतिवाक्यवज्जहल्लक्षणापि न सङ्गच्छते । तत्र तु गङ्गाघोषयोराधाराधेयभावलक्षणस्य वाक्यार्थस्याशेषतो विरुद्धत्वाद्वाक्यार्थमशेषतः परित्यज्य तत्सम्बन्धितीरलक्षणाया युक्तत्वाज्जहल्लक्षणा सङ्गच्छते । अत्र तु परोक्षापरोक्षचैतन्यैकत्वलक्षणस्य वाक्यार्थस्य भागमात्रे विरोधाद्भागान्तरमपि परित्यज्यान्यलक्षणाया अयुक्तत्वाज्जहल्लक्षणा न सङ्गच्छते ।

न च गङ्गापदं स्वार्थपरित्यागेन तीरपदार्थं यथा लक्षयति तथा तत्पदं त्वम्पदं वा स्वार्थपरित्यागेन त्वम्पदार्थं तत्पदार्थं वा लक्षयत्वतः कुतो जहल्लक्षणा न सङ्गच्छत इति वाच्यम् । तत्र तीरपदाश्रवणेन तदर्थाप्रतीतौ लक्षणया तत्प्रतीत्यपेक्षायामपि तत्त्वम्पदयोः श्रूयमाणत्वेन तदर्थप्रतीतौ लक्षणया पुनरन्यतरपदेनान्यतरपदार्थप्रतीत्यपेक्षाभावात् ॥ २५ ॥`,
      mulaIast: "atra gaṅgāyāṁ ghoṣaḥ prativasati iti vākyavad jahal-lakṣaṇāpi na saṅgacchate... || 25 ||",
      padaccheda: "अत्र, गङ्गायाम्, घोषः, प्रतिवसति, इति, वाक्यवत्, जहल्लक्षणा, अपि, न, सङ्गच्छते ...",
      anvaya: "अत्र गङ्गायां घोष इतिवज्जहल्लक्षणापि न सम्भवति, अशेषवाच्यार्थत्यागायोगात् भागमात्रे विरोधात् ।",
      bhashyaExtract: "गङ्गायां घोष इत्यत्र गङ्गाप्रवाहस्य सर्वथा त्यागात्तीरं लक्ष्यते । अत्र तु चैतन्यांशस्यात्यागाज्जहल्लक्षणा न युक्ता ।",
      englishTranslation: "Nor is Exclusive Indication (Jahal-lakṣaṇā) applicable here, as in the sentence 'The cowherd hamlet lives on the Gaṅgā' (Gaṅgāyāṁ ghoṣaḥ). There, because the literal meaning of a village existing in the flowing waters is completely impossible, the direct meaning is totally discarded in favor of the river-bank. But here, the contradiction lies only in one part of the meaning (omniscience vs. limited knowledge); hence discarding the other part (Consciousness itself) and indicating something entirely foreign is completely unjustified.",
      commentaryNotes: "Demonstrates that because Consciousness is preserved in both terms, Jahal-lakṣaṇā (complete abandonment of primary meaning) fails."
    },
    {
      id: "vs-26",
      number: "Section 26",
      title: "Inapplicability of Inclusive Indication (Ajahal-Lakṣaṇā)",
      mulaSanskrit: `अत्र शोणो धावतीति वाक्यवदजहल्लक्षणापि न सम्भवति । तत्र शोणगुणगमनलक्षणस्य वाक्यार्थस्य विरुद्धत्वात्तदपरित्यागेन तदाश्रयाश्वादिलक्षणया तद्विरोधपरिहारसम्भवादजहल्लक्षणा सम्भवति । अत्र तु परोक्षत्वापरोक्षत्वादिविशिष्टचैतन्यैकत्वस्य वाक्यार्थस्य विरुद्धत्वात्तदपरित्यागेन तत्सम्बन्धिनो यस्य कस्यचिदर्थस्य लक्षितत्वेऽपि तद्विरोधपरिहारासम्भवादजहल्लक्षणा न सम्भवत्येव ।

न च तत्पदं त्वम्पदं वा स्वार्थविरुद्धांशपरित्यागेनांशान्तरसहितं त्वम्पदार्थं तत्पदार्थं वा लक्षयत्वतः कथं प्रकारान्तरेण भागलक्षणाङ्गीकरणमिति वाच्यम् । एकेन पदेन स्वार्थांशपदार्थान्तरोभयलक्षणाया असम्भवात्पदान्तरेण तदर्थप्रतीतौ लक्षणया पुनस्तत्प्रतीत्यपेक्षाभावाच्च ॥ २६ ॥`,
      mulaIast: "atra śoṇo dhāvatīti vākyavad ajahal-lakṣaṇāpi na sambhavati... || 26 ||",
      padaccheda: "अत्र, शोणः, धावति, इति, वाक्यवत्, अजहल्लक्षणा, अपि, न, सम्भवति ...",
      anvaya: "शोणो धावतीतिवदजहल्लक्षणापि न सम्भवति, वाच्यार्थापरित्यागे विरोधानिवृत्तेः ।",
      bhashyaExtract: "शोणो धावतीत्यत्र रक्तगुणमपरित्यज्यैवाश्वो लक्ष्यते । अत्र तु परोक्षत्वापरोक्षत्वयोस्त्यागमन्तरा विरोधस्य परिहर्तुमशक्यत्वात् ।",
      englishTranslation: "Nor is Non-Exclusive Indication (Ajahal-lakṣaṇā) possible here, as in the sentence 'The red runs' (Śoṇo dhāvati). There, because the quality 'red' cannot run by itself, the literal meaning is retained while including the horse possessing that redness, thereby resolving the conflict. But here, the contradiction between omniscience and limited individuality cannot be resolved without abandoning those contradictory attributes; retaining them while indicating something related would never resolve the contradiction.",
      commentaryNotes: "Proves that Ajahal-lakṣaṇā cannot resolve the contradiction because contradictory adjuncts must be dropped."
    },
    {
      id: "vs-27",
      number: "Section 27",
      title: "The Triumph of Jahadajahallakṣaṇā / Bhāga-Tyāga-Lakṣaṇā: 'So'yaṁ Devadattaḥ'",
      mulaSanskrit: `तस्माद्यथा सोऽयं देवदत्त इति वाक्यं तदर्थो वा तत्कालैतत्कालविशिष्टदेवदत्तलक्षणस्य वाक्यार्थस्यांशे विरोधाद्विरुद्धतत्कालैतत्कालविशिष्टांशं परित्यज्याविरुद्धं देवदत्तांशमात्रं लक्षयति तथा तत्त्वमसीति वाक्यं तदर्थो वा परोक्षत्वापरोक्षत्वादिविशिष्टचैतन्यैकत्वलक्षणस्य वाक्यार्थस्यांशे विरोधाद्विरुद्धपरोक्षत्वापरोक्षत्वविशिष्टांशं परित्यज्याविरुद्धमखण्डचैतन्यमात्रं लक्षयतीति ॥ २७ ॥`,
      mulaIast: "tasmād yathā so'yaṁ devadatta iti vākyaṁ tadartho vā tatkālaitatkālaviśiṣṭadevadattalakṣaṇasya vākyārthasyāṁśe virodhād viruddhatatkālaitatkālaviśiṣṭāṁśaṁ parityajyāviruddhaṁ devadattāṁśamātraṁ lakṣayati tathā tat-tvam-asīti vākyaṁ tadartho vā parokṣatvāparokṣatvādiviśiṣṭacaitanyaikatvalakṣaṇasya vākyārthasyāṁśe virodhād viruddhaparokṣatvāparokṣatvaviśiṣṭāṁśaṁ parityajyāviruddham akhaṇḍacaitanyamātraṁ lakṣayatīti || 27 ||",
      padaccheda: "तस्मात्, यथा, सः, अयम्, देवदत्तह्, इति, वाक्यम्... तथा, तत्-त्वम्-असि, इति, वाक्यम्, अखण्ड-चैतन्य-मात्रम्, लक्षयति, इति",
      anvaya: "तस्माद्यथा सोऽयं देवदत्त इति वाक्यं विरुद्धकालांशं परित्यज्य देवदत्तमात्रं लक्षयति, तथा तत्त्वमसीति वाक्यं विरुद्धपरोक्षत्वाद्यंशं परित्यज्याखण्डचैतन्यमात्रं लक्षयति ।",
      bhashyaExtract: "भागलक्षणया (जहदजहल्लक्षणया) विरुद्धोपाध्यंशत्यागेनाविरुद्धशुद्धचैतन्यरूपेणैक्यं सिद्ध्यति । अयमेव वेदान्तसिद्धान्तः ।",
      englishTranslation: "Therefore, just as the sentence 'This is that Devadatta' (So'yaṁ Devadattaḥ), upon encountering contradiction in one part regarding past and present time and place, discards the contradictory parts and indicates the non-contradictory essential Devadatta alone; so too the Great Sentence 'Tat Tvam Asi', encountering contradiction in one part regarding remoteness and immediacy, discards the contradictory qualified parts and indicates the non-contradictory, homogeneous, indivisible Pure Consciousness alone.",
      commentaryNotes: "The undisputed pedagogical pinnacle of Kevalādvaita textual hermeneutics, establishing non-dual identity through Bhāgalakṣaṇā."
    }
  ]
};
