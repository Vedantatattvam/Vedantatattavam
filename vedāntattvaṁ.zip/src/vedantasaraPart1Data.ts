import { GranthaChapter } from "./types";

// =========================================================================================
// CHAPTER 1: MAṄGALA & ANUBANDHA-CATUṢṬAYA (Sections 1 - 4)
// =========================================================================================
export const VEDANTASARA_CHAPTER_1: GranthaChapter = {
  id: "vs-adhyaya-1",
  chapterTitle: "Chapter 1: Maṅgalācaraṇa, Anubandha & Sādhana-Catuṣṭaya",
  chapterTitleSanskrit: "प्रथमोऽध्यायः — मङ्गलाचरणम् अनुबन्धचतुष्टयं साधनचतुष्टयञ्च",
  summary:
    "Opening invocations to the non-dual Self and Guru Advayānanda; definitions of Vedānta, the four preliminary qualifications (Anubandha-Catuṣṭaya: Adhikārī, Viṣaya, Sambandha, Prayojana), the preliminary disciplines and discrimination of actions, and the fourfold spiritual means (Sādhana-Catuṣṭaya).",
  verses: [
    {
      id: "vs-1",
      number: "Section 1",
      title: "Maṅgala-Śloka: Salutation to Akhaṇḍa Saccidānanda Ātman",
      mulaSanskrit: "अखण्डं सच्चिदानन्दमवाङ्मनसगोचरम् ।\nआत्मानमखिलाधारमाश्रयेऽभीष्टसिद्धये ॥ १ ॥",
      mulaIast: "akhaṇḍaṁ saccidānandam avāṅmanasagocaram |\nātmānam akhilādhāram āśraye'bhīṣṭasiddhaye || 1 ||",
      padaccheda: "अखण्डम्, सत्-चित्-आनन्दम्, अवाङ्मनसगोचरम्, आत्मानम्, अखिल-आधारम्, आश्रये, अभीष्ट-सिद्धये",
      anvaya: "अखण्डं सच्चिदानन्दम् अवाङ्मनसगोचरम् अखिलाधारम् आत्मानम् अभीष्टसिद्धये आश्रये ।",
      bhashyaExtract: "अखण्डम् एकरसम्, सच्चिदानन्दरूपम्, वाङ्मनसातीतम्, सर्वप्रपञ्चाधिष्ठानं परमात्मानं ग्रन्थनिर्विघ्नपरिसमाप्तये शरणं प्रपद्ये ।",
      englishTranslation: "For the realization of the supreme desired goal (liberation), I take refuge in the Self (Ātman)—which is indivisible (Akhaṇḍa), Existence-Consciousness-Bliss (Sat-Cit-Ānanda), beyond speech and mind, and the eternal substratum of the entire universe.",
      commentaryNotes: "Invocation establishing the unconditioned, homogeneous nature of Ātman as the sole reality and substratum of all phenomenal projection."
    },
    {
      id: "vs-2",
      number: "Section 2",
      title: "Maṅgala-Śloka: Reverence to Guru Advayānanda & Purpose of the Treatise",
      mulaSanskrit: "अर्थतोऽप्यद्वयानन्दानतीतद्वैतभानतः ।\nगुरूनाराध्य वेदान्तसारं वक्ष्ये यथामति ॥ २ ॥",
      mulaIast: "arthato'py advayānandān atītadvaitabhānataḥ |\ngurūn ārādhya vedāntasāraṁ vakṣye yathāmati || 2 ||",
      padaccheda: "अर्थतः, अपि, अद्वय-आनन्दान्, अतीत-द्वैत-भानतः, गुरून्, आराध्य, वेदान्त-सारम्, वक्ष्ये, यथा-मति",
      anvaya: "अतीतद्वैतभानतः अर्थतोऽपि अद्वयानन्दान् गुरून् आराध्य यथामति वेदान्तसारं वक्ष्ये ।",
      bhashyaExtract: "अद्वयानन्दनाम्नः स्वगुरून् प्रणम्य वेदान्तशास्त्रस्य सारभूतं प्रकरणं स्वबुद्ध्यनुसारेण सङ्गृह्य कथयामि ।",
      englishTranslation: "Having worshiped my Guru, named Advayānanda—who is also non-dual bliss in actual reality because he has transcended all appearance of duality—I shall expound the quintessence of Vedānta (Vedāntasāra) according to my understanding.",
      commentaryNotes: "Homage to the preceptor Advayānanda Sarasvatī, utilizing an insightful double-meaning highlighting the Guru's intrinsic absorption in non-dual Reality."
    },
    {
      id: "vs-3",
      number: "Section 3",
      title: "Definition of Vedānta & the Four Prerequisites (Anubandha-Catuṣṭaya)",
      mulaSanskrit: "वेदान्तो नामोपनिषत्प्रमाणं तदुपकारीणि शारीरकसूत्रादीनि च । अस्य वेदान्तप्रकरणत्वात् तदीयैः एव अनुबन्धैः तद्वत्तासिद्धेः न ते पृथगालोचनीयाः । तत्र अनुबन्धो नाम अधिकारिविषयसम्बन्धप्रयोजनानि ॥ ३ ॥",
      mulaIast: "vedānto nāmopaniṣatpramāṇaṁ tadupakārīṇi śārīrakasūtrādīni ca | asya vedāntaprakaraṇatvāt tadīyaiḥ eva anubandhaiḥ tadvattāsiddheḥ na te pṛthagālocanīyāḥ | tatra anubandho nāma adhikāriviṣayasambandhaprayojanāni || 3 ||",
      padaccheda: "वेदान्तः, नाम, उपनिषत्-प्रमाणम्, तदुपकारीणि, शारीरक-सूत्रादीनि, च । अस्य, वेदान्त-प्रकरणत्वात्, तदीयैः, एव, अनुबन्धैः, तद्वत्ता-सिद्धेः, न, ते, पृथक्, आलोचनीयाः । तत्र, अनुबन्धः, नाम, अधिकारि-विषय-सम्बन्ध-प्रयोजनानि",
      anvaya: "वेदान्तो नाम उपनिषत्प्रमाणं तदुपकारीणि शारीरकसूत्रादीनि च । अस्य वेदान्तप्रकरणत्वात् तदीयैरनुबन्धैरेव तद्वत्तासिद्धेस्ते न पृथगालोचनीयाः । तत्रानुबन्धो नामाधिकारिविषयसम्बन्धप्रयोजनानि ।",
      bhashyaExtract: "उपनिषद एव मुख्यं प्रमाणम्, ब्रह्मसूत्राणि तु तदुपकारीणि युक्तिप्रदर्शकतया । प्रकरणमिदं तदन्तर्गतमेवेति तदङ्गाधिकार्यादिभिरेव युक्तम् ।",
      englishTranslation: "By 'Vedānta' is meant the authoritative testimony of the Upaniṣads, together with the Śārīraka Sūtras (Brahma Sūtras) and other treatises that assist in their comprehension. Since this work is a topical manual (Prakaraṇa) of Vedānta, its prerequisites are established by the very prerequisites of Vedānta itself; hence they need not be discussed separately. The preliminary prerequisites (Anubandhas) are: the Qualified Aspirant (Adhikārī), the Subject-matter (Viṣaya), the Relationship (Sambandha), and the Purpose (Prayojana).",
      commentaryNotes: "Formulates the canonical locus of Vedāntic study. Anubandha-catuṣṭaya is mandatory for any classical philosophical treatise to establish its intellectual validity and necessity."
    },
    {
      id: "vs-4",
      number: "Section 4",
      title: "The Qualified Aspirant (Adhikārī), Sādhana-Catuṣṭaya, and the Fruit of Action vs. Knowledge",
      mulaSanskrit: `अधिकारी तु विधिवदधीतवेदवेदाङ्गत्वेनापाततोऽधिगताखिलवेदार्थोऽस्मिन् जन्मनि जन्मान्तरे वा काम्यनिषिद्धवर्जनपुरःसरं नित्यनैमित्तिकप्रायश्चित्तोपासनानुष्ठानेन निर्गतनिखिलकल्मषतया नितान्तनिर्मलस्वान्तः साधनचतुष्टयसम्पन्नः प्रमाता ।

काम्यानि - स्वर्गादीष्टसाधनानि ज्योतिष्टोमादीनि ।
निषिद्धानि - नरकाद्यनिष्टसाधनानि ब्राह्मणहननादीनि ।
नित्यानि - अकरणे प्रत्यवायसाधनानि सन्ध्यावन्दनादीनि ।
नैमित्तिकानि - पुत्रजन्माद्यनुबन्धीनि जातेष्ट्यादीनि ।
प्रायश्चित्तानि - पापक्षयसाधनानि चान्द्रायणादीनि ।
उपासनानि - सगुणब्रह्मविषयमानसव्यापाररूपाणि शाण्डिल्यविद्यादीनि ।

एतेषां नित्यादीनां बुद्धिशुद्धिः परं प्रयोजनम् , उपासनानां तु चित्तैकाग्र्यं 'तमेतमात्मानं वेदानुवचनेन ब्राह्मणा विविदिषन्ति यज्ञेन' (बृ.उ. ४ । ४ । २२) इत्यादिश्रुतेः 'तपसा कल्मषं हन्ति' (मनु. १२ । १०४) इत्यादिस्मृतेश्च । नित्यनैमित्तिकयोः उपासनानां त्ववान्तरफलं पितृलोकसत्यलोकप्राप्तिः 'कर्मणा पितृलोकः विद्यया देवलोकः' (बृ. उ. १ । ५ । १६) इत्यादिश्रुतेः ।

साधनानि - नित्यानित्यवस्तुविवेकेहामुत्रार्थफलभोगविरागशमादिषट्कसम्पत्तिमुमुक्षुत्वानि ।
नित्यानित्यवस्तुविवेकस्तावद् ब्रह्मैव नित्यं वस्तु ततोऽन्यदखिलमनित्यमिति विवेचनम् ।
ऐहिकानां स्रक्चन्दनवनितादिविषयभोगानां कर्मजन्यतयानित्यत्ववदामुष्मिकाणामप्यमृतादिविषयभोगानामनित्यतया तेभ्यो नितरां विरतिः - इहामुत्रार्थफलभोगविरागः ।
शमादयस्तु - शमदमोपरतितितिक्षासमाधानश्रद्धाख्याः ।
शमस्तावत् - श्रवणादिव्यतिरिक्तविषयेभ्यो मनसो निग्रहः ।
दमः - बाह्येन्द्रियाणां तद्व्यतिरिक्तविषयेभ्यो निवर्तनम् ।
निवर्तितानामेतेषां तद्व्यतिरिक्तविषयेभ्य उपरमणमुपरतिरथवा विहितानां कर्मणां विधिना परित्यागः ।
तितिक्षा - शीतोष्णादिद्वन्द्वसहिष्णुता ।
निगृहीतस्य मनसः श्रवणादौ तदनुगुणविषये च समाधिः - समाधानम् ।
गुरूपदिष्टवेदान्तवाक्येषु विश्वासः - श्रद्धा ।
मुमुक्षुत्वम् - मोक्षेच्छा ।

एवम्भूतः प्रमाताधिकारी 'शान्तो दान्तः' (बृ. उ. ४ । ४ । २३) इत्यादिश्रुतेः ।
उक्तञ्च -
'प्रशान्तचित्ताय जितेन्द्रियाय च प्रहीणदोषाय यथोक्तकारिणे ।
गुणान्वितायानुगताय सर्वदा प्रदेयमेतत् सततं मुमुक्षवे' (उपदेशसाहस्री ३२४ । १६ । ७२) इति ॥

विषयः - जीवब्रह्मैक्यम् , शुद्धचैतन्यं प्रमेयम् , तत्र एव वेदान्तानां तात्पर्यात् ।
सम्बन्धस्तु - तदैक्यप्रमेयस्य तत्प्रतिपादकोपनिषत्प्रमाणस्य च बोध्यबोधकभावः ।
प्रयोजनं तु - तदैक्यप्रमेयगताज्ञाननिवृत्तिः स्वस्वरूपानन्दावाप्तिश्च 'तरति शोकम् आत्मवित्' (छां. उ. ७ । १ । ३) इत्यादिश्रुतेः, 'ब्रह्मविद् ब्रह्मैव भवति' (मुं. उ. ३ । २ । ९) इत्यादिश्रुतेश्च ॥ ४ ॥`,
      mulaIast: `adhikārī tu vidhivad adhītavedavedāṅgatvenāpātato'dhigatākhilavedārtho'smin janmani janmāntare vā kāmyaniṣiddhavarjanapuraḥsaraṁ nityanaimittikaprāyaścittopāsanānuṣṭhānena nirgatanikhilakalmaṣatayā nitāntanirmalasvāntaḥ sādhanacatuṣṭayasampannaḥ pramātā |

kāmyāni - svargādīṣṭasādhanāni jyotiṣṭomādīni |
niṣiddhāni - narakādyaniṣṭasādhanāni brāhmaṇahananādīni |
nityāni - akaraṇe pratyavāyasādhanāni sandhyāvandanādīni |
naimittikāni - putrajanmādyanubandhīni jāteṣṭyādīni |
prāyaścittāni - pāpakṣayasādhanāni cāndrāyaṇādīni |
upāsanāni - saguṇabrahmaviṣayamānasavyāpārarūpāṇi śāṇḍilyavidyādīni |

eteṣāṁ nityādīnāṁ buddhiśuddhiḥ paraṁ prayojanam, upāsanānāṁ tu cittaikāgryam...

sādhanāni - nityānityavastuvivekehāmutrārthaphalabhogavirāgaśamādiṣaṭkasampattimumukṣutvāni...

viṣayaḥ - jīvabrahmaikyam, śuddhacaitanyaṁ prameyam...
sambandhas tu - tad-aikyaprameyasya tatpratipādakopaniṣatpramāṇasya ca bodhyabodhakabhāvaḥ |
prayojanaṁ tu - tad-aikyaprameyagatājñānanivṛttiḥ svasvarūpānandāvāptiś ca... || 4 ||`,
      padaccheda: "अधिकारी, तु, विधिवत्, अधीत-वेद-वेदाङ्गत्वेन, आपाततः, अधिगत-अखिल-वेदार्थः, साधन-चतुष्टय-सम्पन्नः, प्रमाता ...",
      anvaya: "अधिकारी तु साधनचतुष्टयसम्पन्नः प्रमाता । विषयस्तु जीवब्रह्मैक्यं शुद्धचैतन्यम् । सम्बन्धस्तु बोध्यबोधकभावः । प्रयोजनं त्वज्ञाननिवृत्तिः स्वस्वरूपानन्दावाप्तिश्च ।",
      bhashyaExtract: "विवेक-वैराग्य-शमादिषट्क-मुमुक्षुत्वरूपसाधनचतुष्टयसम्पन्न एव वेदान्तश्रवणेऽधिक्रियते । विषयस्तु जीवब्रह्मणोरभेदः । प्रयोजनं तु मोक्षः ।",
      englishTranslation: "The competent aspirant (Adhikārī) is the knower who has duly studied the Vedas and Vedāṅgas, gained a general understanding of their teachings, purged all impurities by abandoning desire-prompted (Kāmya) and prohibited (Niṣiddha) actions while performing regular daily (Nitya), occasional (Naimittika), expiatory (Prāyaścitta) duties and meditations (Upāsanā), whose inner mind has become thoroughly purified, and who is endowed with the Fourfold Spiritual Qualifications (Sādhana-Catuṣṭaya: discrimination between the eternal and transient, dispassion for fruits here and hereafter, the sixfold virtues beginning with Śama, and intense yearning for liberation). The Subject-matter (Viṣaya) is the absolute identity of the Jīva and Brahman—Pure Consciousness. The Relationship (Sambandha) is that between the truth to be understood and the Upaniṣadic text revealing it (Bodhya-Bodhaka-Bhāva). The Purpose (Prayojana) is the cessation of ignorance concerning that identity and the realization of one's own nature as Supreme Bliss.",
      commentaryNotes: "The classical definition of Sādhana-Catuṣṭaya and the precise distinctions between Kāmya, Niṣiddha, Nitya, Naimittika, and Prāyaścitta karmas, establishing knowledge as the direct vehicle of Mukti."
    }
  ]
};

// =========================================================================================
// CHAPTER 2: GURU-UPASATTI & ADHYĀROPA-PRAKRIYĀ (Sections 5 - 11)
// =========================================================================================
export const VEDANTASARA_CHAPTER_2: GranthaChapter = {
  id: "vs-adhyaya-2",
  chapterTitle: "Chapter 2: Guru-Upasatti & Adhyāropa-Prakriyā",
  chapterTitleSanskrit: "द्वितीयोऽध्यायः — गुरूपसत्तिः अध्यारोपप्रक्रिया च",
  summary:
    "Approaching the enlightened Guru, the method of deliberate superimposition and sublation (Adhyāropāpavāda-Nyāya), the definition of Vastu (Real) and Avastu (Unreal), the nature of Primordial Ignorance (Ajñāna) with its collective (Samaṣṭi) and individual (Vyaṣṭi) dimensions, Īśvara, Prājña, Turīya, the two powers (Āvaraṇa and Vikṣepa Śakti), and the twofold causality of the cosmos.",
  verses: [
    {
      id: "vs-5",
      number: "Section 5",
      title: "Approaching the Guru (Guru-Upasatti) & Teaching through Adhyāropa-Apavāda",
      mulaSanskrit: `अयमधिकारी जननमरणादिसंसारानलसन्तप्तो दीप्तशिरा जलराशिमिवोपहारपाणिः श्रोत्रियं ब्रह्मनिष्ठं गुरुमुपसृत्य तमनुसरति 'तद्विज्ञानार्थं स गुरुमेवाभिगच्छेत् समित्पाणिः श्रोत्रियं ब्रह्मनिष्ठम्' (मुं. उ. १ । २ । १२) इत्यादिश्रुतेः । स गुरुः परमकृपयाध्यारोपापवादन्यायेनैनमुपदिशति -

'तस्मै स विद्वानुपसन्नया सम्यक् प्रशान्तचित्ताय शमान्विताय ।
येनाक्षरं पुरुषं वेद सत्यं प्रोवाच तां तत्त्वतो ब्रह्मविद्याम् ॥' (मुं. उ. १ । २ । १३) इत्यादिश्रुतेः ॥ ५ ॥`,
      mulaIast: "ayam adhikārī jananamaraṇādisaṁsārānalasantapto dīptaśirā jalarāśim ivopahārapāṇiḥ śrotriyaṁ brahmaniṣṭhaṁ gurum upasṛtya tam anusarati... sa guruḥ paramakṛpayādhyāropāpavādanyāyenainam upadiśati... || 5 ||",
      padaccheda: "अयम्, अधिकारी, जनन-मरणादि-संसार-अनल-सन्तप्तः, दीप्त-शिराः, जल-राशिम्, इव, उपहार-पाणिः, श्रोत्रियम्, ब्रह्म-निष्ठम्, गुरुम्, उपसृत्य, तम्, अनुसरति ...",
      anvaya: "अयमधिकारी संसारानलसन्तप्तः श्रोत्रियं ब्रह्मनिष्ठं गुरुमुपसृत्य तमनुसरति । स गुरुः परमकृपयाध्यारोपापवादन्यायेनैनमुपदिशति ।",
      bhashyaExtract: "श्रोत्रियं वेदतात्पर्यज्ञम्, ब्रह्मनिष्ठं साक्षात्कृताद्वैततत्त्वं देशिकं प्रपद्यते । स च गुरुः अध्यारोपापवादन्यायेन शिष्यं बोधयति ।",
      englishTranslation: "Scorched by the blazing fires of worldly transmigratory existence (birth, death, and suffering), just as one whose head is on fire plunges toward a body of water, this qualified aspirant, bearing gifts in hand, approaches and follows a Guru who is well-versed in the scriptures (Śrotriya) and steadfast in the realization of Brahman (Brahmaniṣṭha). That Guru, out of supreme compassion, instructs him through the dialectical method of deliberate superimposition and subsequent sublation (Adhyāropa-Apavāda-Nyāya).",
      commentaryNotes: "Cites the canonical injunction from Muṇḍaka Upaniṣad (1.2.12-13) highlighting the absolute necessity of a living, realized Guru and the method of Adhyāropāpavāda."
    },
    {
      id: "vs-6",
      number: "Section 6",
      title: "Definition of Superimposition (Adhyāropa), Vastu, Avastu, and Ajñāna",
      mulaSanskrit: `असर्पभूतायां रज्जौ सर्पारोपवत् वस्तुनि अवस्त्वारोपः - अध्यारोपः । वस्तु - सच्चिदानन्दमद्वयं ब्रह्म अज्ञानादिसकलजडसमूहोऽवस्तु । अज्ञानं तु - सदसद्भ्यामनिर्वचनीयं त्रिगुणात्मकं ज्ञानविरोधि भावरूपं यत्किञ्चिदिति वदन्त्यहमज्ञ इत्याद्यनुभवात् 'देवात्मशक्तिं स्वगुणैर्निगूढाम्' (श्वे. उ. १ । ३) इत्यादिश्रुतेश्च ॥ ६ ॥`,
      mulaIast: "asarpabhūtāyāṁ rajjau sarpāropavat vastuni avastvāropaḥ - adhyāropaḥ | vastu - saccidānandam advayaṁ brahma ajñānādisakalajaḍasamūho'vastu | ajñānaṁ tu - sadasadbhyām anirvacanīyaṁ triguṇātmakaṁ jñānavirodhi bhāvarūpaṁ yatkiñcid iti vadanty aham ajña ityādyanubhavāt... || 6 ||",
      padaccheda: "असर्प-भूतायाम्, रज्जौ, सर्प-आरोपवत्, वस्तुनि, अवस्तु-आरोपः, अध्यारोपः । वस्तु, सत्-चित्-आनन्दम्, अद्वयम्, ब्रह्म, अज्ञानादि-सकल-जड-समूहः, अवस्तु । अज्ञानम्, तु, सत्-असद्भ्याम्, अनिर्वचनीयम्, त्रिगुणात्मकम्, ज्ञान-विरोधि, भावरूपम्, यत्-किञ्चित्, इति, वदन्ति ...",
      anvaya: "असर्पभूतायां रज्जौ सर्पारोपवत् वस्तुनि अवस्त्वारोपोऽध्यारोपः । सच्चिदानन्दमद्वयं ब्रह्म वस्तु, अज्ञानादिसकलजडसमूहोऽवस्तु । अज्ञानं तु सदसद्भ्यामनिर्वचनीयं त्रिगुणात्मकं ज्ञानविरोधि भावरूपं यत्किञ्चित् ।",
      bhashyaExtract: "रज्जौ सर्पभ्रान्तिवद्ब्रह्मणि प्रपञ्चभ्रमः । अज्ञानं न अभावः, अपि तु भावरूपमनिर्वचनीयं ज्ञानबाध्यम् ।",
      englishTranslation: "Superimposition (Adhyāropa) is the attribution of the unreal (Avastu) upon the Real (Vastu), just as a serpent is falsely superimposed upon a rope that is not a serpent. The 'Real' (Vastu) is Brahman—Existence-Consciousness-Bliss, non-dual. The 'Unreal' (Avastu) is the entire collection of insentient phenomena beginning with Ignorance (Ajñāna). Ignorance, moreover, is indescribable as either real or unreal (Sadasadbhyām Anirvacanīya), composed of the three Guṇas (Sattva, Rajas, Tamas), contradictory to knowledge, positive in nature (Bhāvarūpa), and indefinable ('something positive'), as proven by universal experience ('I am ignorant') and Śruti ('The divine self-power concealed by its own qualities').",
      commentaryNotes: "The classical definition of Ajñāna (Avidyā) in Kevalādvaita: neither absolute reality (Sat) nor utter non-existence (Asat), but Anirvacanīya and dispelled only by direct knowledge."
    },
    {
      id: "vs-7",
      number: "Section 7",
      title: "Collective (Samaṣṭi) and Individual (Vyaṣṭi) Ignorance: Īśvara and Prājña",
      mulaSanskrit: `इदमज्ञानं समष्टिव्यष्ट्यभिप्रायेणैकमनेकमिति च व्यवह्रियते । तथाहि यथा वृक्षाणां समष्ट्यभिप्रायेण वनमित्येकत्वव्यपदेशो यथा वा जलानां समष्ट्यभिप्रायेण जलाशय इति तथा नानात्वेन प्रतिभासमानानां जीवगताज्ञानानां समष्ट्यभिप्रायेण तदेकत्वव्यपदेशः, 'अजामेकाम्' (श्वे. उ. ४ । ५) इत्यादिश्रुतेः । इयं समष्टिरुत्कृष्टोपाधितया विशुद्धसत्त्वप्रधाना । एतदुपहितं चैतन्यं सर्वज्ञत्वसर्वेश्वरत्वसर्वनियन्तृत्वादिगुणकमव्यक्तमन्तर्यामी जगत्कारणमीश्वर इति च व्यपदिश्यते सकलाज्ञानावभासकत्वात् । 'यः सर्वज्ञः सर्ववित्' (मुं. उ. १ । १ । ९) इति श्रुतेः । ईश्वरस्येयं समष्टिरखिलकारणत्वात्कारणशरीरमानन्दप्रचुरत्वात्कोशवदाच्छादकत्वाच्चानन्दमयकोशः सर्वोपरमत्वात्सुषुप्तिरत एव स्थूलसूक्ष्मप्रपञ्चलयस्थानमिति च उच्यते ।

यथा वनस्य व्यष्ट्यभिप्रायेण वृक्षा इत्यनेकत्वव्यपदेशो यथा वा जलाशयस्य व्यष्ट्यभिप्रायेण जलानीति तथाज्ञानस्य व्यष्ट्यभिप्रायेण तदनेकत्वव्यपदेशः 'इन्द्रो मायाभिः पुरुरूप ईयते' (ऋग्वेद ६ । ४७ । १८) इत्यादिश्रुतेः । अत्र व्यस्तसमस्तव्यापित्वेन व्यष्टिसमष्टिताव्यपदेशः । इयं व्यष्टिर्निकृष्टोपाधितया मलिनसत्त्वप्रधाना । एतदुपहितं चैतन्यमल्पज्ञत्वानीश्वरत्वादिगुणकं प्राज्ञ इत्युच्यत एकाज्ञानावभासकत्वात् । अस्य प्राज्ञत्वमस्पष्टोपाधितयाऽनतिप्रकाशकत्वात् । अस्यापीयमहङ्कारादिकारणत्वात्कारणशरीरमानन्दप्रचुरत्वात्कोशवदाच्छादकत्वाच्चानन्दमयकोशः सर्वोपरमत्वात्सुषुप्तिरत एव स्थूलसूक्ष्मशरीरप्रपञ्चलयस्थानमिति च उच्यते ॥ ७ ॥`,
      mulaIast: `idam ajñānaṁ samaṣṭivyaṣṭyabhiprāyeṇa ekam anekam iti ca vyavahriyate... iyaṁ samaṣṭir utkṛṣṭopādhitayā viśuddhasattvapradhānā | etad-upahitaṁ caitanyaṁ sarvajñatva-sarveśvaratva-sarvaniyantṛtvādi-guṇakam avyaktam antaryāmī jagatkāraṇam īśvara iti ca vyapadiśyate... iyaṁ vyaṣṭir nikṛṣṭopādhitayā malinasattvapradhānā | etad-upahitaṁ caitanyam alpajñatvānīśvaratvādi-guṇakaṁ prājña ity ucyate... || 7 ||`,
      padaccheda: "इदम्, अज्ञानम्, समष्टि-व्यष्टि-अभिप्रायेण, एकम्, अनेकम्, इति, च, व्यवह्रियते ...",
      anvaya: "इदमज्ञानं समष्टिव्यष्ट्यभिप्रायेणैकमनेकमिति च व्यवह्रियते । विशुद्धसत्त्वप्रधानसमष्ट्युपहितं चैतन्यं सर्वज्ञत्वादिगुणकमीश्वरः । मलिनसत्त्वप्रधानव्यष्ट्युपहितं चैतन्यमल्पज्ञत्वादिगुणकं प्राज्ञः ।",
      bhashyaExtract: "यथा वनवृक्षयोर्भेदः काल्पनिकस्तथा समष्टिव्यष्ट्योः । विशुद्धसत्त्वोपहित ईश्वरः, मलिनसत्त्वोपहितो जीवः प्राज्ञः ।",
      englishTranslation: "This Ignorance is spoken of as one or manifold, depending on whether it is viewed collectively (Samaṣṭi) or individually (Vyaṣṭi). Just as trees viewed collectively are called a single 'forest', or waters viewed collectively are designated a 'reservoir', similarly the manifold ignorances inhering in individual souls, when viewed collectively, are referred to as one, as in the Śruti: 'The unborn one (Prakṛti), red, white, and black...' This collective ignorance, being a superior adjunct, is predominated by pure Sattva (Viśuddha-Sattva). Consciousness conditioned by this collective ignorance, endowed with omniscience, universal Lordship, and supreme rulership, is designated the Unmanifest, the Inner Controller (Antaryāmī), the Cause of the Universe, and Īśvara, because it illumines all collective ignorance. On the other hand, viewed individually (just as a forest broken down is trees), it is designated manifold. This individual ignorance, being an inferior adjunct, is predominated by impure Sattva (Malina-Sattva). Consciousness conditioned by it, endowed with limited knowledge and lack of lordship, is called Prājña. For both, this ignorance is the Causal Body (Kāraṇa-Śarīra), the Sheath of Bliss (Ānandamayakośa), and Deep Sleep (Suṣupti), where the gross and subtle worlds dissolve.",
      commentaryNotes: "Elucidates the metaphysical parallelism between macrocosmic Īśvara and microcosmic Prājña within the causal plane of Avidyā."
    },
    {
      id: "vs-8",
      number: "Section 8",
      title: "Experience of Īśvara & Prājña in Deep Sleep and their Essential Non-Difference",
      mulaSanskrit: `तदानीमेतावीश्वरप्राज्ञौ चैतन्यप्रदीप्ताभिरतिसूक्ष्माभिरज्ञानवृत्तिभिरानन्दमनुभवतः 'आनन्दभुक् चेतोमुखः प्राज्ञः' (मां. उ. ५) इति श्रुतेः सुखमहमवाप्सम् न किञ्चिदवेदिषमित्युत्थितस्य परामर्शोपपत्तेश्च । अनयोः समष्टिव्यष्ट्योर्वनवृक्षयोरिव जलाशयजलयोरिव वा भेदः । एतदुपहितयोरीश्वरप्राज्ञयोरपि वनवृक्षावच्छिन्नाकाशयोरिव जलाशयजलगतप्रतिबिम्बाकाशयोरिव वा भेदः 'एष सर्वेश्वर' (मां. उ. ६) इत्यादिश्रुतेः ॥ ८ ॥`,
      mulaIast: "tadānīm etāv īśvaraprājñau caitanyapradīptābhir atisūkṣmābhir ajñānavṛttibhir ānandam anubhavataḥ... sukhah aham avāpsam na kiñcid avediṣam ity utthitasya parāmarśopapatteś ca... || 8 ||",
      padaccheda: "तदानीम्, एतौ, ईश्वर-प्राज्ञौ, चैतन्य-प्रदीप्ताभिः, अति-सूक्ष्माभिः, अज्ञान-वृत्तिभिः, आनन्दम्, अनुभवतः ...",
      anvaya: "तदानीमेतावीश्वरप्राज्ञौ चैतन्यप्रदीप्ताभिरतिसूक्ष्माभिरज्ञानवृत्तिभिरानन्दमनुभवतः । अनयोः समष्टिव्यष्ट्योर्वनवृक्षयोरिव भेदः, उपहितयोरपि वनवृक्षावच्छिन्नाकाशयोरिवाभेदः ।",
      bhashyaExtract: "सुषुप्तौ अज्ञानेनैव आनन्दानुभवः, न तु शुद्धब्रह्मसाक्षात्कारः । समष्टिव्यष्ट्युपाधिभेदात्तु भेदो भासते, वस्तुतस्त्वेकमेव चैतन्यम् ।",
      englishTranslation: "At that time (in deep sleep), both Īśvara and Prājña experience bliss through extremely subtle modifications of ignorance illumined by Consciousness, as attested by Śruti: 'The enjoyer of bliss, whose doorway is consciousness, is Prājña' (Māṇḍūkya 5), and corroborated by the recollective experience upon waking: 'I slept happily, I knew nothing.' The difference between this collective and individual ignorance is merely like that between a forest and individual trees, or a body of water and droplets. The difference between Īśvara and Prājña conditioned by them is likewise merely like the sky enclosed by a forest and the sky enclosed by individual trees, or the sky reflected in a reservoir and that reflected in water droplets.",
      commentaryNotes: "Explains how the bliss of deep sleep is still mediated by subtle Ajñāna-vṛttis, and establishes the essential identity behind Īśvara and Prājña."
    },
    {
      id: "vs-9",
      number: "Section 9",
      title: "Turīya: The Unconditioned Substratum of Pure Consciousness",
      mulaSanskrit: `वनवृक्षतदवच्छिन्नाकाशयोर्जलाशयजलतद्गतप्रतिबिम्बाकाशयोर्वाऽऽधारभूताऽऽनुपहिताऽऽकाशवदनयोरज्ञानतदुपहितचैतन्ययोराऽऽधारभूतं यदनुपहितं चैतन्यं तत्तुरीयमित्युच्यते 'शान्तं शिवमद्वैतं चतुर्थं मन्यन्ते' (मां. उ. ७) इत्यादिश्रुतेः । इदमेव तुरीयं शुद्धचैतन्यमज्ञानादितदुपहितचैतन्याभ्यां तप्तायःपिण्डवदविविक्तं सन्महावाक्यस्य वाच्यं विविक्तं सल्लक्ष्यमिति चोच्यते ॥ ९ ॥`,
      mulaIast: "vanavṛkṣatadavacchinnākāśayor jalaśayajalatadgatapratibimbākāśayor vā'dhārabhūtānupahitākāśavad anayor ajñānatadupahitacaitanyayor ādhārabhūtaṁ yad anupahitaṁ caitanyaṁ tat turīyam ity ucyate... || 9 ||",
      padaccheda: "वन-वृक्ष-तदवच्छिन्न-आकाशयोः, जलाशय-जल-तद्गत-प्रतिबिम्ब-आकाशयोः, वा, आधार-भूत-अनुपहित-आकाशवत्, अनयोः, अज्ञान-तदुपहित-चैतन्ययोः, आधार-भूतम्, यत्, अनुपहितम्, चैतन्यम्, तत्, तुरीयम्, इति, उच्यते ...",
      anvaya: "अज्ञानतदुपहितचैतन्ययोराधारभूतं यदनुपहितं चैतन्यं तत्तुरीयमित्युच्यते । इदमेव शुद्धचैतन्यमविविक्तं सन्महावाक्यस्य वाच्यं विविक्तं सल्लक्ष्यं चोच्यते ।",
      bhashyaExtract: "सर्वोपाधिविनिर्मुक्तं शुद्धं ब्रह्मैव तुरीयम् । तदेव महावाक्येन 'तत्' 'त्वम्' इति पदाभ्यां लक्ष्यार्थतया प्रतिपाद्यते ।",
      englishTranslation: "Just as there is an unconditioned, underlying all-pervading sky which serves as the ultimate substratum for the forest, the trees, and the sky enclosed or reflected within them, so too that unconditioned Consciousness which serves as the ultimate substratum for ignorance and the consciousness conditioned by it, is called the Fourth (Turīya), as declared by the Śruti: 'They consider that peaceful, auspicious, and non-dual to be the Fourth' (Māṇḍūkya 7). This very Turīya, pure unconditioned Consciousness, when undiscriminated from ignorance and conditioned consciousness like an incandescent red-hot iron ball, is the expressed meaning (Vācyārtha) of the Great Vedic Dictum; when discriminated, it is the indicated essence (Lakṣyārtha).",
      commentaryNotes: "Introduces the red-hot iron ball (Taptāyaḥ-piṇḍa) analogy to explain how pure Consciousness appears unified with gross/subtle/causal adjuncts until discriminated."
    },
    {
      id: "vs-10",
      number: "Section 10",
      title: "The Two Powers of Ignorance: Veiling Power (Āvaraṇa) & Projecting Power (Vikṣepa)",
      mulaSanskrit: `अस्य अज्ञानस्य आवरणविक्षेपनामकमस्ति शक्तिद्वयम्। आवरणशक्तिस्तावदल्पोऽपि मेघोऽनेकयोजनायतमादित्यमण्डलमवलोकयितृनयनपथपिधायकतया यथाऽऽच्छादयतीव तथा अज्ञानं परिच्छिन्नमपि आत्मानमपरिच्छिन्नमसंसारिणमवलोकयितृबुद्धिपिधायकतयाऽऽच्छादयतीव तादृशं सामर्थ्यम् ।

तदुक्तं -
'घनच्छन्नदृष्टिर्घनच्छन्नमर्कं यथा मन्यते निष्प्रभं चातिमूढः ।
तथा बद्धवद्भाति यो मूढदृष्टेः स नित्योपलब्धिस्वरूपोऽहमात्मा ॥' (हस्तामलकम् १०) इति ।

अनया आवृतस्यात्मनः कर्तृत्वभोक्तृत्वसुखित्वदुःखित्वादिसंसारसम्भावनापि भवति यथा स्वाऽज्ञानेनावृतायां रज्ज्वां सर्पत्वसम्भावना । विक्षेपशक्तिस्तु यथा रज्ज्वज्ञानं स्वावृतरज्जौ स्वशक्त्या सर्पादिकमुद्भावयत्येवमज्ञानमपि स्वावृतात्मनि स्वशक्त्याऽऽकाशादिप्रपञ्चमुद्भावयति तादृशं सामर्थ्यम् । तदुक्तम् - 'विक्षेपशक्तिर्लिङ्गादि ब्रह्माण्डान्तं जगत् सृजेत्' (वाक्यसुधा १३) इति ॥ १० ॥`,
      mulaIast: `asya ajñānasya āvaraṇavikṣepanāmakam asti śaktidvayam | āvaraṇaśaktis tāvad alpo'pi megho'nekayojanāyatam ādityamaṇḍalam avalokayitṛnayanapathapidhāyakatayā yathā''chādayatīva tathā ajñānaṁ paricchinnam api ātmānam aparicchinnam asaṁsāriṇam avalokayitṛbuddhipidhāyakatayā''chādayatīva tādṛśaṁ sāmarthyam... vikṣepaśaktis tu yathā rajjvajñānaṁ svāvṛtarajjau svaśaktyā sarpādikam udbhāvayaty evam ajñānam api svāvṛtātmani svaśaktyā''kāśādiprapañcam udbhāvayati... || 10 ||`,
      padaccheda: "अस्य, अज्ञानस्य, आवरण-विक्षेप-नामकम्, अस्ति, शक्ति-द्वयम् । आवरण-शक्तिः, तावत् ... विक्षेप-शक्तिः, तु ...",
      anvaya: "अस्याज्ञानस्यावरणविक्षेपनामकं शक्तिद्वयमस्ति । आवरणशक्तिरात्मानमाच्छादयतीव । विक्षेपशक्तिस्त्वावृतात्मन्याकाशादिप्रपञ्चमुद्भावयति ।",
      bhashyaExtract: "आवरणशक्तिर्ज्ञानप्रतिबन्धिका, विक्षेपशक्तिस्तु प्रपञ्चोत्पादिका । रज्ज्वज्ञानेन रज्ज्वावरणं सर्पाध्यासश्चेति दृष्टान्तः ।",
      englishTranslation: "This Ignorance possesses two distinct powers: the Veiling Power (Āvaraṇa-śakti) and the Projecting Power (Vikṣepa-śakti). The Veiling Power is that capacity by which, just as a tiny patch of cloud obscuring the viewer's line of vision appears to cover the vast solar disc of many leagues, so too finite ignorance, by concealing the intellect of the observer, appears to conceal the infinite, unattached Self. Through this veiled condition arises the transmigratory delusion of agency, enjoyership, pleasure, and pain, just as the appearance of a snake arises on a veiled rope. The Projecting Power is that potency by which, just as the ignorance of a rope projects a serpent upon the veiled rope, so too ignorance projects the entire phenomenal universe beginning with space upon the veiled Self. As declared: 'The projecting power creates the entire world from the subtle body up to the cosmic egg' (Vākyasudhā 13).",
      commentaryNotes: "Crucial Kevalādvaita psychological and metaphysical doctrine: Āvaraṇa conceals the real (Svarūpācchādikā), while Vikṣepa superimposes the unreal universe (Vividha-kāryotpadikā)."
    },
    {
      id: "vs-11",
      number: "Section 11",
      title: "Consciousness as Efficient (Nimitta) and Material (Upādāna) Cause: The Spider Analogy",
      mulaSanskrit: `शक्तिद्वयवदज्ञानोपहितं चैतन्यं स्वप्रधानतया निमित्तं स्वोपाधिप्रधानतयोपादानं च भवति । यथा लूता तन्तुकार्यं प्रति स्वप्रधानतया निमित्तं स्वशरीरप्रधानतयोपादानञ्च भवति ॥ ११ ॥`,
      mulaIast: "śaktidvayavad-ajñānopahitaṁ caitanyaṁ svapradhānatayā nimittaṁ svopādhipradhānatayopādānaṁ ca bhavati | yathā lūtā tantukāryaṁ prati svapradhānatayā nimittaṁ svaśarīrapradhānatayopādānañ ca bhavati || 11 ||",
      padaccheda: "शक्तिद्वयवत्-अज्ञान-उपहितम्, चैतन्यम्, स्व-प्रधानतया, निमित्तम्, स्व-उपाधि-प्रधानतया, उपादानम्, च, भवति । यथा, लूता, तन्तु-कार्यम्, प्रति, स्व-प्रधानतया, निमित्तम्, स्व-शरीर-प्रधानतया, उपादानम्, च, भवति",
      anvaya: "शक्तिद्वयवदज्ञानोपहितं चैतन्यं स्वप्रधानतया निमित्तं स्वोपाधिप्रधानतयोपादानं च भवति, यथा लूता तन्तुकार्यं प्रति स्वप्रधानतया निमित्तं स्वशरीरप्रधानतयोपादानं च भवति ।",
      bhashyaExtract: "अभिन्ननिमित्तोपादानकारणं ब्रह्म । चैतन्यरूपेण निमित्तम्, अज्ञानोपाधिरूपेण उपादानम् । लूतादृष्टान्तेन श्रुतिसिद्धोऽयमर्थः ।",
      englishTranslation: "Consciousness conditioned by ignorance endowed with these twofold powers becomes the efficient cause (Nimitta-kāraṇa) by virtue of its own conscious nature, and the material cause (Upādāna-kāraṇa) by virtue of its limiting adjunct (ignorance). Just as a spider is both the efficient cause of its web through its own intelligence and the material cause through the substance of its own body.",
      commentaryNotes: "Defines Brahman as the Undifferentiated Material and Efficient Cause (Abhinna-Nimittopādāna-Kāraṇa) of the universe, resolving the creation paradox."
    }
  ]
};
