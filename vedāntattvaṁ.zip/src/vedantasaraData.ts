import { TextEntry } from "./types";
import { VEDANTASARA_CHAPTER_1, VEDANTASARA_CHAPTER_2 } from "./vedantasaraPart1Data";
import { VEDANTASARA_CHAPTER_3, VEDANTASARA_CHAPTER_4, VEDANTASARA_CHAPTER_5 } from "./vedantasaraPart2Data";
import { VEDANTASARA_CHAPTER_6, VEDANTASARA_CHAPTER_7 } from "./vedantasaraPart3Data";

export const VEDANTASARA_GRANTHA: TextEntry = {
  id: "vedantasara",
  title: "Vedāntasāra",
  transliteratedTitle: "Vedāntasāra (वेदान्तसारः — केवलद्वैतप्रकरणग्रन्थः)",
  author: "Śrī Sadānanda Yogīndra Sarasvatī (श्रीमत्सदानन्दयोगीन्द्रः)",
  century: "15th Century CE (c. 1500 CE)",
  school: "Advaita Vedānta (Kevalādvaita — Śaṅkara Paramparā)",
  paramparaId: "advaita",
  schoolTag: "Prakaraṇa Grantha",
  foundationalText: "Canonical Introductory Manual of Kevalādvaita Vedānta (38 Sections in 7 Chapters)",
  totalVersesOrSutras: "38 Canonical Sections across 7 Chapters (Prose & Metric Kārikās)",
  language: "Classical Philosophical Sanskrit (संस्कृतम्)",
  scriptStyle: "Gadya, Sūtra & Kārikā Exposition",
  description:
    "The Vedāntasāra ('The Essence of Vedānta') composed by Śrī Sadānanda Yogīndra Sarasvatī is the universally celebrated introductory treatise (Prakaraṇa Grantha) of the Kevalādvaita school of Ādi Śaṅkarācārya. Celebrated for its crystal-clear pedagogical architecture, it systematically expounds the entire arc of non-dual philosophy: starting from the fourfold qualification (Anubandha-Catuṣṭaya and Sādhana-Catuṣṭaya), the dialectical method of deliberate superimposition and sublation (Adhyāropāpavāda-Nyāya), the twofold power of ignorance (Āvaraṇa and Vikṣepa Śakti), the cosmic evolution of subtle and gross bodies through Pañcīkaraṇa, the refutation of the materialist and nihilist views from body to void (Dehātma-vāda to Śūnyavāda), the rigorous semantic hermeneutics of 'Tat Tvam Asi' through Jahadajahallakṣaṇā (Bhāgalakṣaṇā), the awakening of the indivisible mental modification (Akhaṇḍākāra-cittavṛtti), the distinction between Vṛtti-vyāpti and Phala-vyāpti, the practical path of contemplation (Śravaṇa, Manana, Nididhyāsana, and Nirvikalpaka Samādhi overcoming its four obstacles), culminating in the living glory of Jīvanmukti and supreme Videhamukti.",
  refutationsDet:
    "Systematically refutes all misconceptions regarding the Self (Anātma-vāda): worldly identification with one's progeny (Putra as Ātman), Cārvāka identifications with the physical body (Dehātma-vāda), sense organs (Indriyātma-vāda), vital breath (Prāṇātma-vāda), and mind (Manātma-vāda); Yogācāra Buddhist identification with momentary consciousness (Vijñānātma-vāda); Mīmāṁsaka and Naiyāyika identification with ignorance (Ajñāna as Ātman); Bhāṭṭa identification with consciousness veiled by darkness; and Mādhyamika Buddhist nihilism (Śūnyavāda / absolute void as Ātman). In textual hermeneutics, it refutes the syntactic contact theory (Saṁsarga) and qualified union (Viśiṣṭa) of Viśiṣṭādvaita, as well as the misapplication of Jahal-lakṣaṇā and Ajahal-lakṣaṇā to the Mahāvākya. In ethics, it refutes antinomian license (Yatheṣṭācaraṇa).",
  supportsDet:
    "Firmly establishes the fundamental doctrines of Kevalādvaita Vedānta: Anubandha-Catuṣṭaya (Adhikārī, Viṣaya, Sambandha, Prayojana) and Sādhana-Catuṣṭaya (Viveka, Vairāgya, Śamādi-ṣaṭka, Mumukṣutva); Adhyāropa and Apavāda as the supreme pedagogical method; the nature of Avidyā/Ajñāna as positive, composed of three gunas, and indescribable (Sadasadbhyām Anirvacanīya); the veiling (Āvaraṇa) and projecting (Vikṣepa) cosmic potencies; Vivartavāda (apparent illusory appearance) over Pariṇāmavāda; macrocosmic-microcosmic identity across the three bodies (Kāraṇa: Īśvara/Prājña, Sūkṣma: Hiraṇyagarbha/Taijasa, Sthūla: Virāṭ/Viśva); Pañcīkaraṇa (quinquipartition); Bhāga-Tyāga-Lakṣaṇā resolving 'Tat Tvam Asi' into indivisible homogeneous Consciousness (Akhaṇḍārtha); 'Ahaṁ Brahmāsmi' and the Akhaṇḍākāra-cittavṛtti; Vṛtti-vyāpti for dispelling ignorance without Phala-vyāpti; the sixfold criteria of purport (Upakrama-Upasaṁhāra, Abhyāsa, Apūrvatā, Phala, Arthavāda, Upapatti); Aṣṭāṅga-Yoga supporting Nirvikalpaka Samādhi; conquering the four spiritual obstacles (Laya, Vikṣepa, Kaṣāya, Rasāsvāda); and the living reality of Jīvanmukti where virtues (Amānitva, Adveṣṭṛtva) flow spontaneously as natural ornaments (Alaṅkāra), culminating in Videhamukti.",
  chapters: [
    VEDANTASARA_CHAPTER_1,
    VEDANTASARA_CHAPTER_2,
    VEDANTASARA_CHAPTER_3,
    VEDANTASARA_CHAPTER_4,
    VEDANTASARA_CHAPTER_5,
    VEDANTASARA_CHAPTER_6,
    VEDANTASARA_CHAPTER_7
  ]
};
