import { GranthaChapter } from "./types";

// =========================================================================================
// CHAPTER 6: SĀKṢĀTKĀRA, VṚTTI-VYĀPTI & SĀDHANA-MĀRGA (Sections 28 - 33)
// =========================================================================================
export const VEDANTASARA_CHAPTER_6: GranthaChapter = {
  id: "vs-adhyaya-6",
  chapterTitle: "Chapter 6: Sākṣātkāra, Vṛtti-Vyāpti & Sādhana-Mārga",
  chapterTitleSanskrit: "षष्ठोऽध्यायः — साक्षात्कारः वृत्तिव्याप्तिः साधनमार्गश्च",
  summary:
    "Direct realization through the experiential dictum 'Ahaṁ Brahmāsmi'; the Akhaṇḍākāra-cittavṛtti; the famous distinction between Vṛtti-vyāpti and Phala-vyāpti; the threefold discipline (Śravaṇa, Manana, Nididhyāsana); the sixfold criteria of textual purport (Ṣaḍ-viṅdha-liṅga); Savikalpaka and Nirvikalpaka Samādhi; the eight limbs of Yoga; the four obstacles (Laya, Vikṣepa, Kaṣāya, Rasāsvāda); and the unshakeable flame of absorption.",
  verses: [
    {
      id: "vs-28",
      number: "Section 28",
      title: "'Ahaṁ Brahmāsmi': The Experiential Dictum & Akhaṇḍākāra-Cittavṛtti",
      mulaSanskrit: `अथाधुना 'अहं ब्रह्मास्मि' (बृ. उ. १ । ४ । १०) इत्यनुभववाक्यार्थो वर्ण्यते । एवमाचार्येणाध्यारोपापवादपुरःसरं तत्त्वम्पदार्थौ शोधयित्वा वाक्येनाखण्डार्थेऽवबोधितेऽधिकारिणोऽहं नित्यशुद्धबुद्धमुक्तसत्यस्वभावपरमानन्दानन्ताद्वयं ब्रह्मास्मीत्यखण्डाकाराकारिता चित्तवृत्तिरुदेति । सा तु चित्प्रतिबिम्बसहिता सती प्रत्यगभिन्नमज्ञातं परम्ब्रह्म विषयीकृत्य तद्गताज्ञानमेव बाधते तदा पटकारणतन्तुदाहे पटदाहवदखिलकारणेऽज्ञाने बाधिते सति तत्कार्यस्याखिलस्य बाधितत्वात्तदन्तर्भूताखण्डाकाराकारिता चित्तवृत्तिरपि बाधिता भवति ।

तत्र प्रतिबिम्बितं चैतन्यमपि यथा दीपप्रभाऽऽदित्यप्रभाऽवभासनाऽसमर्था सती तयाऽभिभूता भवति तथा स्वयम्प्रकाशमानप्रत्यगभिन्नपरब्रह्माऽवभासनाऽनर्हतया तेनाभिभूतं सत् स्वोपाधिभूताखण्डवृत्तेर्बाधितत्वाद्दर्पणाभावे मुखप्रतिबिम्बस्य मुखमात्रत्ववत्प्रत्यगभिन्नपरब्रह्ममात्रं भवति ॥ २८ ॥`,
      mulaIast: `athādhunā 'ahaṁ brahmāsmi' ity anubhavavākyārtho varṇyate... adhikāriṇo'haṁ nityaśuddhabuddhamuktasatyasvabhāvaparāmānandānantādvayaṁ brahmāsmīty akhaṇḍākārākāritā cittavṛttir udeti... || 28 ||`,
      padaccheda: "अथ, अधुना, अहम्, ब्रह्म, अस्मि, इति, अनुभव-वाक्य-अर्थः, वर्ण्यते ... अखण्डाकार-आकारिता, चित्त-वृत्तिः, उदेति ...",
      anvaya: "वाक्येनाखण्डार्थेऽवबोधितेऽधिकारिणोऽहं ब्रह्मास्मीत्यखण्डाकाराकारिता चित्तवृत्तिरुदेति । सा चाज्ञानं बाधते, कारणनाशे कार्यनाशवत् सा स्वयमपि लीयते, शुद्धचैतन्यमात्रमवशिष्यते ।",
      bhashyaExtract: "अखण्डाकारवृत्त्या अज्ञानध्वंसः । ततो वृत्तिरपि शाम्यति कतकफलवद्दर्पणाभावे मुखमात्रवच्च ।",
      englishTranslation: "Now is described the meaning of the experiential sentence 'Ahaṁ Brahmāsmi' ('I am Brahman', Bṛhadāraṇyaka 1.4.10). When the Teacher, by means of superimposition and sublation, has purified the terms 'Tat' and 'Tvam' and revealed the non-dual Truth through the Great Dictum, there arises in the qualified aspirant the indivisible mental modification (Akhaṇḍākāra-cittavṛtti): 'I am Brahman—eternally pure, conscious, liberated, the reality, supreme bliss, infinite, and non-dual.' That modification, accompanied by the reflection of Consciousness (Cidābhāsa), taking the unknown Supreme Brahman as its object, destroys primal ignorance. When primal ignorance, the root cause of all phenomena, is burnt like the threads of a cloth causing the cloth itself to burn, all its effects are destroyed, and that very mental modification is also sublated. The reflected consciousness within it, unable to illumine the self-luminous Brahman, merges into the pure, non-different Supreme Brahman, just as the reflection of a face merges into the face when the mirror is removed.",
      commentaryNotes: "Explains how the final Akhaṇḍākāra-vṛtti destroys Avidyā and then spontaneously dissolves itself, leaving pure self-luminous Brahman."
    },
    {
      id: "vs-29",
      number: "Section 29",
      title: "Reconciliation of Scriptural Contradiction: Vṛtti-Vyāpti vs. Phala-Vyāpti",
      mulaSanskrit: `एवं च सति 'मनसैवानुद्रष्टव्यम्' (बृ. उ. ४ । ४ । १९) 'यन्मनसा न मनुते' (के. उ. १ । ६) इत्यनयोः श्रुत्योरविरोधो वृत्तिव्याप्यत्वाङ्गीकारेण फलव्याप्यत्वप्रतिषेधप्रतिपादनात् । तदुक्तम् -

'फलव्याप्यत्वमेवास्य शास्त्रकृद्भिर्निवारितम् ।
ब्रह्मण्यज्ञाननाशाय वृत्तिव्याप्तिरपेक्षिता ॥' इति (पञ्चदशी ६ । ९०) ।

'स्वयम्प्रकाशमानत्वान्नाभास उपयुज्यते ।' इति च (पञ्चदशी ६ । ९२) ।

जडपदार्थाकाराकारितचित्तवृत्तेर्विशेषोऽस्ति । यथा दीपप्रभामण्डलमन्धकारगतं घटपटादिकं विषयीकृत्य तद्गतान्धकारनिरसनपुरःसरं स्वप्रभया तदपि भासयतीति । तथाहि - अयं घट इति घटाकाराकारितचित्तवृत्तिरज्ञातं घटं विषयीकृत्य तद्गताज्ञाननिरसनपुरःसरं स्वगतचिदाभासेन जडं घटमपि भासयति । तदुक्तम् -

'बुद्धितत्स्थचिदाभासौ द्वावपि व्याप्नुतो घटम् ।
तत्राज्ञानं धिया नश्येदाभासेन घटः स्फुरेत् ॥' इति । (पञ्चदशी ७ । ९१) ॥ २९ ॥`,
      mulaIast: `evaṁ ca sati 'manasaivānudraṣṭavyam' 'yan manasā na manute' ity anayoḥ śrutyor avirodho vṛttivyāpyatvāṅgīkāreṇa phalavyāpyatvapratiṣedhapratipādanāt... 'phalavyāpyatvam evāsya śāstrakṛdbhir nivāritam | brahmaṇy ajñānanāśāya vṛttivyāptir apekṣitā ||'... || 29 ||`,
      padaccheda: "एवम्, च, सति, मनसा, एव, अनुद्रष्टव्यम्... यत्, मनसा, न, मनुते... अनयोः, श्रुत्योः, अविरोधः, वृत्ति-व्याप्यत्वाङ्गीकारेण, फल-व्याप्यत्व-प्रतिषेध-प्रतिपादनात् ...",
      anvaya: "वृत्तिव्याप्यत्वाङ्गीकारेण फलव्याप्यत्वप्रतिषेधाच्छ्रुत्योरविरोधः । ब्रह्मण्यज्ञाननाशाय वृत्तिव्याप्तिरपेक्षिता, फलव्याप्यत्वं तु निवारितम्, स्वयम्प्रकाशमानत्वात् ।",
      bhashyaExtract: "घटादौ अज्ञाननाशाय वृत्तिः, प्रकाशाय चिदाभासश्चोभयमपेक्षितम् । ब्रह्मणि तु अज्ञाननाशायैव वृत्तिर्व्याप्नोति, स्वयं भासमानत्वात् चिदाभासो न प्रभवति ।",
      englishTranslation: "Thus there is complete harmony between the Śrutis declaring 'By the mind alone It is to be perceived' (Bṛhadāraṇyaka 4.4.19) and 'That which cannot be thought by the mind' (Kena 1.6); for the scriptures accept Vṛtti-vyāpti (pervasion by the mental modification to dispel ignorance) while denying Phala-vyāpti (pervasion by the reflected light of consciousness). As stated: 'Pervasion by the fruit (Phala-vyāpti) is denied by the author of the Śāstras; but pervasion by the mental modification (Vṛtti-vyāpti) is required in Brahman solely for the destruction of ignorance' (Pañcadaśī 6.90). In the case of insentient objects like a pot, both the mental modification and the reflected consciousness are required—the intellect destroys ignorance and the reflection illumines the pot. But because Brahman is self-luminous, no reflected light is required to illumine It.",
      commentaryNotes: "The classical resolution of whether Brahman is knowable: Brahman is Vṛtti-vyāpya (object of mental mode to dispel Avidyā) but never Phala-vyāpya (dependent on reflected consciousness)."
    },
    {
      id: "vs-30",
      number: "Section 30",
      title: "Śravaṇa, Manana, Nididhyāsana, Ṣaḍ-Viṅdha-Liṅga, and the Two Samādhis",
      mulaSanskrit: `एवं भूतस्वस्वरूपचैतन्यसाक्षात्कारपर्यन्तं श्रवणमनननिदिध्यासनसमाध्यनुष्ठानस्यापेक्षितत्वात् तेऽपि प्रदर्श्यन्ते ।

श्रवणं नाम षड्विधलिङ्गैरशेषवेदान्तानामद्वितीयवस्तुनि तात्पर्यावधारणम् । लिङ्गानि तूपक्रमोपसंहाराभ्यासापूर्वताफलार्थवादोपपत्त्याख्यानि । तदुक्तम् -

'उपक्रमोपसंहारावभ्यासोऽपूर्वता फलम् ।
अर्थवादोपपत्ती च लिङ्गं तात्पर्यनिर्णये ॥'

प्रकरणप्रतिपाद्यस्यार्थस्य तदाद्यन्तयोरुपपादनमुपक्रमोपसंहारौ... पौनःपुन्येन प्रतिपादनमभ्यासः... प्रमाणान्तराविषयीकरणमपूर्वता... प्रयोजनं फलम्... प्रशंसनमर्थवादः... युक्तिरुपपत्तिः...

मननं तु श्रुतस्याद्वितीयवस्तुनो वेदान्तानुगुणयुक्तिभिरनवरतमनुचिन्तनम् ।

विजातीयदेहादिप्रत्ययरहिताद्वितीयवस्तुसजातीयप्रत्ययप्रवाहो निदिध्यासनम् ।

समाधिर्द्विविधः सविकल्पको निर्विकल्पश्चेति । तत्र सविकल्पको नाम ज्ञातृज्ञानादिविकल्पलयानपेक्षया अद्वितीयवस्तुनि तदाकाराकारितायाश्चित्तवृत्तेरवस्थानम्... निर्विकल्पकस्तु ज्ञातृज्ञानादिविकल्पलयापेक्षया अद्वितीयवस्तुनि तदाकाराकारितायाश्चित्तवृत्तेः अतितरामेकीभावेनावस्थानम् । तदा तु जलाकाराकारितलवणानवभासेन जलमात्रावभासवदद्वितीयवस्त्वाकाराकारितचित्तवृत्त्यनवभासेनाद्वितीयवस्तुमात्रम् अवभासते ॥ ३० ॥`,
      mulaIast: `evaṁ bhūtasvasvarūpacaitanyasākṣātkāraparyantaṁ śravaṇamananadididhyāsanasamādhyanuṣṭhānasyāpekṣitatvāt... śravaṇaṁ nāma ṣaḍvidhaliṅgair aśeṣavedāntānām advitīyavastuni tātparyāvadhāraṇam... mananaṁ tu... nididhyāsanaṁ tu... samādhir dvividhaḥ savikalpako nirvikalpaś ceti... || 30 ||`,
      padaccheda: "श्रवणम्, नाम, षड्विध-लिङ्गैः, अशेष-वेदान्तानाम्, अद्वितीय-वस्तुनि, तात्पर्यावधारणम् ... मननम् ... निदिध्यासनम् ... समाधिः, द्विविधः, सविकल्पकः, निर्विकल्पकः, च ...",
      anvaya: "श्रवणं नाम षड्विधलिङ्गैर्वेदान्तानामद्वितीये तात्पर्यावधारणम् । मननं युक्त्याऽनुचिन्तनम् । निदिध्यासनं सजातीयप्रत्ययप्रवाहः । समाधिः सविकल्पको निर्विकल्पकश्च ।",
      bhashyaExtract: "षड्भिर्लिङ्गैः श्रुतेरद्वितीये तात्पर्यं निश्चीयते । निर्विकल्पके तु चित्तवृत्तिरपि लवणवल्लीना भवति, केवलं ब्रह्मैवावभासते ।",
      englishTranslation: "Until the direct realization of one's true nature as Pure Consciousness is achieved, the practice of Hearing (Śravaṇa), Reflection (Manana), Meditation (Nididhyāsana), and Absorption (Samādhi) is required. Śravaṇa is the ascertainment of the purport of all Vedāntic texts in the non-dual Reality through the sixfold criteria of determination: 1. Initial and concluding passages (Upakrama-Upasaṁhāra); 2. Repetition (Abhyāsa); 3. Originality / un-knowability through other means (Apūrvatā); 4. Result / fruit (Phala); 5. Eulogistic appraisal (Arthavāda); and 6. Intelligible reasoning (Upapatti). Manana is the continuous reflection on the non-dual Reality using arguments concordant with Vedānta. Nididhyāsana is the unbroken continuous stream of consciousness centered on the non-dual Reality, purged of foreign thoughts like the body. Samādhi is twofold: Savikalpaka (absorption where the distinction of knower, knowledge, and known is still latent) and Nirvikalpaka (total absorption where all triputī distinctions dissolve, and the mind becomes so unified with the non-dual Reality that, just as salt dissolved in water is no longer visible and water alone appears, the mental modification is not perceived and non-dual Brahman alone shines).",
      commentaryNotes: "Systematic articulation of the classical Vedāntic epistemological pathway and the distinction between Savikalpaka and Nirvikalpaka Samādhi."
    },
    {
      id: "vs-31",
      number: "Section 31",
      title: "The Eight Limbs (Aṣṭāṅga-Yoga) Supporting Nirvikalpaka Samādhi",
      mulaSanskrit: `अस्याङ्गानि यमनियमासनप्राणायामप्रत्याहारधारणाध्यानसमाधयः । तत्र 'अहिंसासत्यास्तेयब्रह्मचर्यापरिग्रहा यमाः' । 'शौचसन्तोषतपःस्वाध्यायेश्वरप्रणिधानानि नियमाः' । 'करचरणादिसंस्थानविशेषलक्षणानि पद्मस्वस्तिकादीन्यासनानि' । 'रेचकपूरककुम्भकलक्षणाः प्राणनिग्रहोपायाः प्राणायामाः' । 'इन्द्रियाणां स्वस्वविषयेभ्यः प्रत्याहरणं प्रत्याहारः' । 'अद्वितीयवस्तुनि अन्तरिन्द्रियधारणं धारणा' । 'तत्राद्वितीयवस्तुनि विच्छिद्य विच्छिद्यान्तरिन्द्रियवृत्तिप्रवाहो ध्यानम्' । समाधिस्तूक्तः सविकल्पक एव ॥ ३१ ॥`,
      mulaIast: "asyāṅgāni yamaniyamāsanaprāṇāyāmapratyāhāradhāraṇādhyānasamādhayaḥ... samādhis tūktaḥ savikalpaka eva || 31 ||",
      padaccheda: "अस्य, अङ्गानि, यम-नियम-आसन-प्राणायाम-प्रत्याहार-धारणा-ध्यान-समाधयः ...",
      anvaya: "निर्विकल्पकस्याङ्गानि यम-नियम-आसन-प्राणायाम-प्रत्याहार-धारणा-ध्यान-सविकल्पकसमाधयः सन्ति ।",
      bhashyaExtract: "पातञ्जलोक्तयोगाङ्गानि वेदान्तोक्ते निर्विकल्पकसमाधौ चित्तशुद्ध्यर्थं सहकारिकारणतयाङ्गीक्रियन्ते ।",
      englishTranslation: "The auxiliary limbs (Aṅgas) of Nirvikalpaka Samādhi are: Restraint (Yama), Observance (Niyama), Posture (Āsana), Breath Control (Prāṇāyāma), Withdrawal of senses (Pratyāhāra), Concentration (Dhāraṇā), Meditation (Dhyāna), and Absorption (Savikalpaka Samādhi). Here Yama consists of non-violence, truthfulness, non-stealing, continence, and non-possessiveness. Niyama consists of purity, contentment, austerity, sacred study, and devotion to God. Āsana consists of stable postures such as Padmāsana and Svastikāsana. Prāṇāyāma is the regulation of vital breath through exhalation, inhalation, and retention. Pratyāhāra is withdrawing the senses from their objects. Dhāraṇā is fixing the mind on the non-dual Reality. Dhyāna is the intermittent stream of the mind on the non-dual Reality. Samādhi here refers to the aforementioned Savikalpaka Samādhi, which acts as the direct threshold to Nirvikalpaka.",
      commentaryNotes: "Harmonizes Patañjali's Aṣṭāṅga-Yoga as auxiliary stepping-stones leading up to the Vedāntic Nirvikalpaka realization."
    },
    {
      id: "vs-32",
      number: "Section 32",
      title: "The Four Obstacles to Nirvikalpaka Samādhi: Laya, Vikṣepa, Kaṣāya, and Rasāsvāda",
      mulaSanskrit: `एवमस्याङ्गिनो निर्विकल्पकस्य लयविक्षेपकषायरसास्वादलक्षणाश्चत्वारो विघ्नाः सम्भवन्ति ।

लयस्तावदखण्डवस्त्वनवलम्बनेन चित्तवृत्तेर्निद्रा ।

अखण्डवस्त्वनवलम्बनेन चित्तवृत्तेरन्यावलम्बनं विक्षेपः ।

लयविक्षेपाभावेऽपि चित्तवृत्तेः रागादिवासनया स्तब्धीभावादखण्डवस्त्वनवलम्बनं कषायः ।

अखण्डवस्त्वनवलम्बनेनापि चित्तवृत्तेः सविकल्पकानन्दास्वादनं रसास्वादः । समाध्यारम्भसमये सविकल्पकानन्दास्वादनं वा ॥ ३२ ॥`,
      mulaIast: `evam asyāṅgino nirvikalpakasya layavikṣepakaṣāyarasāsvādalakṣaṇāś catvāro vighnāḥ bhavanti | layas tāvad akhaṇḍavastvanavalambanena cittavṛtter nidrā... vikṣepaḥ... kaṣāyaḥ... rasāsvādaḥ... || 32 ||`,
      padaccheda: "एवम्, अस्य, अङ्गिनः, निर्विकल्पकस्य, लय-विक्षेप-कषाय-रसास्वाद-लक्षणाः, चत्वारः, विघ्नाः, सम्भवन्ति ...",
      anvaya: "निर्विकल्पकस्य चत्वारो विघ्नाः—लयः, विक्षेपः, कषायः, रसास्वादश्चेति ।",
      bhashyaExtract: "चित्तस्य निद्रा लयो भवति, विषयासक्तिर्विक्षेपः, संस्कारजाड्यं कषायः, सविकल्पकानन्दतृप्तिश्च रसास्वादः । एते विघ्नास्त्याज्याः ।",
      englishTranslation: "For this principal Nirvikalpaka Samādhi, four obstacles can arise: Torpor (Laya), Distraction (Vikṣepa), Stagnation (Kaṣāya), and Enjoyment of Taste (Rasāsvāda). 1. Laya (Torpor) is the mind falling into sleep without resting on the indivisible Reality. 2. Vikṣepa (Distraction) is the mind resting on external objects instead of resting on the indivisible Reality. 3. Kaṣāya (Stagnation) is the mind becoming numb or paralyzed by dormant attachments and impressions, failing to rest on the indivisible Reality even in the absence of sleep and distraction. 4. Rasāsvāda (Enjoyment of Taste) is the mind relishing the inferior bliss of Savikalpaka Samādhi, or enjoying bliss at the threshold of Samādhi rather than merging into the unconditioned Reality.",
      commentaryNotes: "One of the most psychologically penetrating diagnostic passages for spiritual practitioners, identifying subtle traps on the path of Samādhi."
    },
    {
      id: "vs-33",
      number: "Section 33",
      title: "Transcending the Four Obstacles: Nirvāta-Dīpa Samādhi",
      mulaSanskrit: `अनेन विघ्नचतुष्टयेन विरहितं चित्तं निर्वातदीपवदचलं सदखण्डचैतन्यमात्रमवतिष्ठते यदा तदा निर्विकल्पकः समाधिरित्युच्यते । यदुक्तम् -

'लये सम्बोधयेच्चितं विक्षिप्तं शमयेत्पुनः ।
सकषायं विजानीयात्समप्राप्तं न चालयेत् ॥
नास्वादयेद्रसं तत्र निःसङ्गः प्रज्ञया भवेत्' (गौडपादकारिका ३ । ४४-४५) इति च,
'यथा दीपो निवातस्थो नेङ्गते सोपमा स्मृता' (भ. गी. ६ । १९) इति च ॥ ३३ ॥`,
      mulaIast: `anena vighnacatuṣṭayena virahitaṁ cittaṁ nirvātadīpavad acalaṁ sad akhaṇḍacaitanyamātram avatiṣṭhate yadā tadā nirvikalpakaḥ samādhir ity ucyate... || 33 ||`,
      padaccheda: "अनेन, विघ्न-चतुष्टयेन, विरहितम्, चित्तम्, निर्वात-दीपवत्, अचलम्, सत्, अखण्ड-चैतन्य-मात्रम्, अवतिष्ठते, यदा, तदा, निर्विकल्पकः, समाधिः, इति, उच्यते ...",
      anvaya: "विघ्नचतुष्टयविरहितं चित्तं यदा निर्वातदीपवदचलं सदखण्डचैतन्यमात्रमवतिष्ठते तदा निर्विकल्पकः समाधिरित्युच्यते ।",
      bhashyaExtract: "गौडपादाचार्यवचनेन सर्वविघ्ननिरासे सति निष्प्रकम्पं चित्तं ब्रह्मणि लीयते ।",
      englishTranslation: "When the mind, completely free from these four obstacles, remains unmoving like a flame in a windless place and rests as indivisible Consciousness alone, then it is called Nirvikalpaka Samādhi. As stated by Gauḍapādācārya: 'When the mind falls into torpor, awaken it; when distracted, pacify it again; recognize it when tainted with dormant passions; when it reaches equanimity, do not disturb it! Let one not taste the transient joy there, but remain unattached through discriminative wisdom' (Māṇḍūkya Kārikā 3.44-45); and as declared in the Bhagavad Gītā: 'As a lamp in a windless place does not flicker, such is the simile recognized of the disciplined mind' (Gītā 6.19).",
      commentaryNotes: "Cites the celebrated verses from Gauḍapāda and the Bhagavad Gītā establishing the pristine equilibrium of Nirvikalpaka Samādhi."
    }
  ]
};

// =========================================================================================
// CHAPTER 7: JĪVANMUKTI & VIDEHAMUKTI (Sections 34 - 38)
// =========================================================================================
export const VEDANTASARA_CHAPTER_7: GranthaChapter = {
  id: "vs-adhyaya-7",
  chapterTitle: "Chapter 7: Jīvanmukti & Videhamukti",
  chapterTitleSanskrit: "सप्तमोऽध्यायः — जीवन्मुक्तिः विदेहमुक्तिश्च",
  summary:
    "The nature of the Living-Liberated sage (Jīvanmukta); the destruction of all accumulated karma; engagement with prārabdha without psychological bondage; spontaneous virtuous conduct (Adveṣṭṛtvādi) as natural ornaments; and the final state of Disembodied Liberation (Videhamukti / Parama-Kaivalya).",
  verses: [
    {
      id: "vs-34",
      number: "Section 34",
      title: "Characteristics of the Jīvanmukta & Destruction of Sañcita Karma",
      mulaSanskrit: `अथ जीवन्मुक्तलक्षणमुच्यते । जीवन्मुक्तो नाम स्वस्वरूपाखण्डब्रह्मज्ञानेन तदज्ञानबाधनद्वारा स्वस्वरूपाखण्डब्रह्मणि साक्षात्कृतेऽज्ञानतत्कार्यसञ्चितकर्मसंशयविपर्ययादीनामपि बाधितत्वादखिलबन्धरहितो ब्रह्मनिष्ठः ।

'भिद्यते हृदयग्रन्थिश्छिद्यन्ते सर्वसंशयाः ।
क्षीयन्ते चास्य कर्माणि तस्मिन्दृष्टे परावरे ॥' (मुं. उ. २ । २ । ९) इत्यादिश्रुतेः ॥ ३४ ॥`,
      mulaIast: `atha jīvanmuktalakṣaṇam ucyate | jīvanmukto nāma svasvarūpākhaṇḍabrahmajñānena tadajñānabādhandvārā... 'bhidyate hṛdayagranthiś chidyante sarvasaṁśayāḥ | kṣīyante cāsya karmāṇi tasmin dṛṣṭe parāvare ||' ityādi-śruteḥ || 34 ||`,
      padaccheda: "अथ, जीवन्मुक्त-लक्षणम्, उच्यते । जीवन्मुक्तः, नाम, स्वस्वरूप-अखण्ड-ब्रह्मज्ञानेन... अखिल-बन्ध-रहितः, ब्रह्म-निष्ठः",
      anvaya: "जीवन्मुक्तो नाम ब्रह्मज्ञानेनाज्ञाने तदन्तर्गते सञ्चितकर्मणि संशयविपर्यये च बाधिते सति जीवन्नेव बन्धरहितो ब्रह्मनिष्ठः ।",
      bhashyaExtract: "जीवन्नेव मुक्तो जीवन्मुक्तः । तस्य अविद्यानिवृत्तौ सर्वे बन्धा विनश्यन्ति, हृदयेऽहङ्कारग्रन्थिर्भज्यते ।",
      englishTranslation: "Now the characteristics of the Living-Liberated (Jīvanmukta) are described. The Jīvanmukta is one who, through direct realization of his true nature as the indivisible Brahman, has dispelled primal ignorance and, because of that sublation of ignorance along with its effects—accumulated past karma (Sañcita), doubts, and false notions—is entirely free from all bondage while still living in the body, firmly established in Brahman. As declared in the Śruti: 'The knot of the heart is rent asunder, all doubts are severed, and all one's karmas are dissipated, when That which is both the higher and the lower is seen' (Muṇḍaka Upaniṣad 2.2.9).",
      commentaryNotes: "Defines the core Kevalādvaita doctrine of Jīvanmukti: liberation is not post-mortem, but immediate direct gnosis in the present life."
    },
    {
      id: "vs-35",
      number: "Section 35",
      title: "The Jīvanmukta's Bodily State and Perception of Prārabdha as Indrajāla",
      mulaSanskrit: `अयं तु व्युत्थानसमये मांसशोणितमूत्रपुरीषादिभाजनेन शरीरेणान्ध्यमान्द्यापटुत्वादिभाजनेन इन्द्रियग्रामेणाशनापिपासाशोकमोहादिभाजनेनान्तःकरणेन च पूर्वपूर्ववासनया क्रियमाणानि कर्माणि भुज्यमानानि ज्ञानाविरुद्धारब्धफलानि च पश्यन्नपि बाधितत्वात्परमार्थतो न पश्यते । यथेन्द्रजालमिति ज्ञानवांस्तदिन्द्रजालं पश्यन्नपि परमार्थमिदमिति न पश्यति । 'सचक्षुरचक्षुरिव सकर्णोऽकर्ण इव' इत्यादिश्रुतेः । उक्तञ्च -

'सुषुप्तवज्जाग्रति यो न पश्यति द्वयं च पश्यन्नपि चाद्वयत्वतः ॥
तथा च कुर्वन्नपि निष्क्रियश्च यः स आत्मविन्नान्य इतीह निश्चयः ॥' इति (उपदेशसाहस्री ५) ॥ ३५ ॥`,
      mulaIast: "ayaṁ tu vyutthānasamaye māṁsaśoṇitamūtrapurīṣādibhājanena śarīreṇa... paśyann api bādhitatvāt paramārthato na paśyate... 'sucakṣur acakṣur iva sakarṇo'karṇa iva' ityādi-śruteḥ... || 35 ||",
      padaccheda: "अयम्, तु, व्युत्थान-समये, मांस-शोणित... शरीरेण... भुज्यमानानि, ज्ञानाविरुद्ध-आरब्ध-फलानि, पश्यन्, अपि, बाधितत्वात्, परमार्थतः, न, पश्यते ...",
      anvaya: "अयं व्युत्थानसमये प्रारब्धफलानि पश्यन्नपि बाधितत्वादिन्द्रजालवत् परमार्थतो न पश्यति । 'स चक्षुरचक्षुरिव' भवति ।",
      bhashyaExtract: "यथा गारुडिको मायिकं सर्पं पश्यन्नपि न बिभेति तथा ज्ञानी देहेन्द्रियप्रपञ्चं बाधितमनुभवन् न बध्यते ।",
      englishTranslation: "When this sage returns to outer awareness (Vyutthāna), he witnesses actions performed by his body (that receptacle of flesh, blood, and waste), by his senses (subject to blindness and weakness), and by his mind (subject to hunger, thirst, grief, and infatuation) according to past latent tendencies, and experiences the un-opposed fruits of commenced karma (Prārabdha); yet, because they are sublated, he does not view them as ultimately real. Just as a spectator who knows that a magic show is an illusion perceives the magical display but does not consider it real. As stated in the Śruti: 'Possessing eyes, he is as if without eyes; possessing ears, he is as if without ears'; and as declared by Ādi Śaṅkara: 'He who, in the waking state, does not see duality just as in deep sleep, or seeing duality perceives only the Non-dual; and who, though acting, remains actionless—he alone is the Knower of the Self, no other; this is the firm conclusion' (Upadeśasāhasrī 5).",
      commentaryNotes: "Explains how the Jīvanmukta witnesses bodily action and Prārabdha without losing awareness of their illusory nature (Bādhita-Anuvṛtti)."
    },
    {
      id: "vs-36",
      number: "Section 36",
      title: "Spontaneous Virtuous Conduct and Absence of License",
      mulaSanskrit: `अस्य ज्ञानात्पूर्वं विद्यमानानामेवाहारविहारादीनामनुवृत्तिवच्छुभवासनानामेवानुवृत्तिर्भवति शुभाशुभयोरौदासीन्यं वा । तदुक्तम् -

'बुद्धाद्वैतसतत्त्वस्य यथेष्टाचराणं यदि ।
शुनां तत्त्वदृशाञ्चैव को भेदोऽशुचिभक्षणे ॥' इति (नैष्कर्म्यसिद्धिः ४ । ६२),
'ब्रह्मवित्तं तथा मुक्त्वा स आत्मज्ञो न चेतरः ॥' इति च (उपदेशसाहस्री ११५) ॥ ३६ ॥`,
      mulaIast: "asya jñānāt pūrvaṁ vidyamānānām evāhāravihārādīnām anuvṛttivac chubhavāsanānām evānuvṛttir bhavati śubhāśubhayor audāsīnyaṁ vā... 'buddhādvaitasatattvasya yatheṣṭācaraṇaṁ yadi | śunāṁ tattvadṛśāñ caiva ko bhedo'śucibhakṣaṇe ||' iti... || 36 ||",
      padaccheda: "अस्य, ज्ञानात्, पूर्वम्, विद्यमानानाम्, एव, आहार-विहारादीनाम्, अनुवृत्तिवत्, शुभ-वासनानाम्, एव, अनुवृत्तिः, भवति ...",
      anvaya: "अस्य ज्ञानात्पूर्ववदेव शुभवासनानामेवानुवृत्तिर्भवति । यथेष्टाचरणं न भवति, 'बुद्धाद्वैतसतत्त्वस्य यथेष्टाचरणं यदि' इति दोषात् ।",
      bhashyaExtract: "ज्ञानिनो यथेष्टाचरणं न युज्यते । अहङ्काराभावात् पापप्रवृत्त्यनुपपत्तिः, पूर्वसंस्काराच्च शुभमेवाचरति ।",
      englishTranslation: "Just as habitual activities like eating and recreation continue automatically from before illumination, so too only pure, wholesome inclinations (Śubha-Vāsanās) continue spontaneously in him, or else utter indifference to both good and bad fortune. For him there is never arbitrary, licentious conduct. As declared by Sureśvarācārya: 'If one who has realized the supreme truth of non-duality were to act licentiously as he pleases, what difference would there be between a dog eating filth and an enlightened seer?' (Naiṣkarmyasiddhi 4.62); and: 'Renouncing the boastful pride of being a Knower of Brahman, he alone is the true Knower of the Self, no one else' (Upadeśasāhasrī 115).",
      commentaryNotes: "Firmly refutes the antinomian heresy: liberation does not license immoral action; rather, ego-death ensures spontaneous ethical purity."
    },
    {
      id: "vs-37",
      number: "Section 37",
      title: "Virtues (Adveṣṭṛtvādi) as Spontaneous Ornaments, Not Striving Disciplines",
      mulaSanskrit: `तदानीममानित्वादीनि ज्ञानसाधनान्यद्वेष्ट्टत्वादयः सद्गुणाश्चालङ्कारवदनुवर्तन्ते । तदुक्तम् -

'उत्पन्नात्मावबोधस्य ह्यद्वेष्ट्टत्वादयो गुणाः ।
अयत्नतो भवन्त्यस्य न तु साधनरूपिणः ॥' इति (नैष्कर्म्यसिद्धिः ४ । ६९) ॥ ३७ ॥`,
      mulaIast: "tadānīm amānitvādīni jñānasādhanāny adveṣṭṛtvādayaḥ sadguṇāś cālaṅkāravad anuvartante | taduktam - 'utpannātmāvabodhasya hy adveṣṭṛtvādayo guṇāḥ | ayatnato bhavanty asya na tu sādhanarūpiṇaḥ ||' iti... || 37 ||",
      padaccheda: "तदानीम्, अमानित्वादीनि, ज्ञान-साधनानि, अद्वेष्टृत्वादयः, सद्गुणाः, च, अलङ्कारवत्, अनुवर्तन्ते ...",
      anvaya: "तदानीममानित्वादयोऽद्वेष्टृत्वादयश्च गुणा अलङ्कारवदनुवर्तन्ते, अयत्नतो भवन्ति न तु साधनरूपिणः ।",
      bhashyaExtract: "अमानित्व-अहिंसा-अद्वेषादयो गुणाः साधनावस्थायां प्रयत्नेन साध्याः, सिद्धावस्थायां तु स्वाभाविकालङ्काररूपा भवन्ति ।",
      englishTranslation: "At that time, virtues such as absence of pride (Amānitva) and absence of hatred towards all living beings (Adveṣṭṛtva) follow him naturally like ornaments. As declared: 'In one who has awakened to the direct knowledge of the Self, qualities like non-hatred arise effortlessly without conscious striving; they no longer serve as spiritual disciplines, but have become his natural character' (Naiṣkarmyasiddhi 4.69).",
      commentaryNotes: "Celebrated distinction between virtues as conscious means (Sādhana) for the seeker, and as spontaneous, natural ornaments (Alaṅkāra) of the Sage."
    },
    {
      id: "vs-38",
      number: "Section 38",
      title: "Videhamukti (Disembodied Liberation) and the Supreme Kaivalya: Concluding Benediction",
      mulaSanskrit: `किं बहुनायं देहयात्रामात्रार्थमिच्छानिच्छापरेच्छाप्रापितानि सुखदुःखलक्षणान्यारब्धफलान्यनुभवन्नन्तःकरणाभासादीनाम् अवभासकः संस्तदवसाने प्रत्यगानन्दपरब्रह्मणि प्राणे लीने सत्यज्ञानतत्कार्यसंस्काराणामपि विनाशात्परमकैवल्यमानन्दैकरसमखिलभेदप्रतिभासरहितम् अखण्डब्रह्मावतिष्ठते । 'न तस्य प्राणा उत्क्रामन्ति' (बृ. उ. ४ । ४ । ६), 'अत्रैव समवनीयन्ते' (बृ. उ. ३ । २ । ११), 'विमुक्तश्च विमुच्यते' (क. उ. ५ । १) इत्यादिश्रुतेः ॥ ३८ ॥

॥ इति श्रीमत्परमहंसपरिव्राजकाचार्य-सदानन्दयोगीन्द्र-विरचितो वेदान्तसारनामको ग्रन्थः सम्पूर्णः ॥`,
      mulaIast: "kiṁ bahunāyaṁ dehayātrāmātrārtham... prārabdhaphalāny anubhavan... tadavasāne pratyagānandaparabrahmaṇi prāṇe līne saty ajñānatatkāryasaṁskārāṇām api vināśāt paramakaivalyam ānandaikarasam akhilabhedapratibhāsarahitam akhaṇḍabrahmāvatiṣṭhate... iti śrīmat-paramahaṁsa-parivrājakācārya-sadānandayogīndra-viracito vedāntasāranāmako granthaḥ sampūrṇaḥ || 38 ||",
      padaccheda: "किम्, बहुना, अयम्, देह-यात्रा-मात्रार्थम्, प्रारब्ध-फलानि, अनुभवन्, तदवसाने, प्रत्यगानन्द-परब्रह्मणि, प्राणे, लीने, सति, परमकैवल्यम्... अखण्ड-ब्रह्म, अवतिष्ठते ...",
      anvaya: "प्रारब्धावसाने प्राणे प्रत्यगानन्दे लीने सत्यज्ञानादिसंस्कारविनाशादखिलभेदरहितमखण्डब्रह्मावतिष्ठते ।",
      bhashyaExtract: "प्रारब्धक्षये सति देहपाते विदेहमुक्तिर्भवति । प्राणा न कुत्रचिदुत्क्रामन्ति, अत्रैव ब्रह्मणि विलीयन्ते । विमुक्तश्च सन् विमुच्यते ।",
      englishTranslation: "What more need be said? Sustaining his body merely for the maintenance of physical life while experiencing pleasure and pain brought about by commenced karma (Prārabdha)—whether prompted by his own desire, without desire, or by the desire of others—and shining as the illuminator of the intellect and its reflections; upon the exhaustion of that commenced karma, when his vital breaths dissolve into the innermost Blissful Supreme Brahman, and all traces of ignorance and its impressions are utterly extinguished, he remains as Absolute Liberation (Parama-Kaivalya)—homogeneous bliss, devoid of any perception of difference, indivisible Brahman alone. As declared in the Śrutis: 'His vital breaths do not depart' (Bṛhadāraṇyaka 4.4.6); 'Right here they merge' (Bṛhadāraṇyaka 3.2.11); and 'Being already liberated, he is liberated from embodiment' (Kaṭha 5.1).\n\nThus concludes the treatise entitled Vedāntasāra, composed by the illustrious Paramahaṁsa Parivrājakācārya, Śrī Sadānanda Yogīndra.",
      commentaryNotes: "The glorious culmination of Vedāntasāra, articulating Videhamukti where even the subtle body dissolves, leaving solely the unconditioned, homogeneous Sat-Cit-Ānanda."
    }
  ]
};
